Option Strict On
Option Explicit On

Imports System.Collections.Generic
Imports System.Linq

Public Enum MoveFilter
    All = 0
    InboundOnly = 1
    OutboundOnly = 2
End Enum

''' <summary>1棚ぶんの集計結果。段を合算するモードでは、同じ間口の棚は同じ値になる。</summary>
Public Class HeatEntry
    Public Property Location As Shelf
    ''' <summary>集計単位のキー(棚コード or 間口キー)。3D側の選択・Top10表示で使う。</summary>
    Public Property LocationKey As String = ""
    Public Property InCount As Integer
    Public Property OutCount As Integer
    Public ReadOnly Property Value As Integer
        Get
            Return InCount + OutCount
        End Get
    End Property
End Class

Public Class HeatResult
    Public ReadOnly Property Entries As New List(Of HeatEntry)()
    Public Property MaxValue As Integer
    ''' <summary>期間・種別で絞り込んだ後の入出庫件数(棚マスタに存在するもののみ)。</summary>
    Public Property TotalCount As Integer
End Class

''' <summary>入出庫履歴から「棚ごとの入出庫回数」を集計する。ヒートマップの値 = 回数(数量ではない)。</summary>
Public Module HeatmapService

    Public Function KeyOf(s As Shelf, mergeLevels As Boolean) As String
        Return If(mergeLevels, s.BayKey, s.ShelfCode)
    End Function

    Public Function IsAllowed(filter As MoveFilter, kind As MoveKind) As Boolean
        If filter = MoveFilter.InboundOnly Then Return kind = MoveKind.Inbound
        If filter = MoveFilter.OutboundOnly Then Return kind = MoveKind.Outbound
        Return True
    End Function

    ''' <param name="mergeLevels">True=段を合算して間口単位で集計 / False=棚(段)ごと</param>
    Public Function Calculate(shelves As List(Of Shelf), txs As List(Of StockTransaction),
                              fromDate As DateTime, toDate As DateTime,
                              filter As MoveFilter, mergeLevels As Boolean) As HeatResult

        Dim keyByShelf As New Dictionary(Of String, String)()
        For Each s As Shelf In shelves
            keyByShelf(s.ShelfCode) = KeyOf(s, mergeLevels)
        Next

        Dim inByKey As New Dictionary(Of String, Integer)()
        Dim outByKey As New Dictionary(Of String, Integer)()
        Dim fromInclusive As DateTime = fromDate.Date
        Dim toExclusive As DateTime = toDate.Date.AddDays(1)
        Dim total As Integer = 0

        For Each t As StockTransaction In txs
            If t.TxDateTime < fromInclusive OrElse t.TxDateTime >= toExclusive Then Continue For
            If Not IsAllowed(filter, t.MoveType) Then Continue For
            Dim key As String = Nothing
            If Not keyByShelf.TryGetValue(t.ShelfCode, key) Then Continue For   ' マスタに無い棚は無視
            If t.MoveType = MoveKind.Inbound Then
                inByKey(key) = GetOrZero(inByKey, key) + 1
            Else
                outByKey(key) = GetOrZero(outByKey, key) + 1
            End If
            total += 1
        Next

        Dim result As New HeatResult()
        result.TotalCount = total
        For Each s As Shelf In shelves
            Dim e As New HeatEntry()
            e.Location = s
            e.LocationKey = keyByShelf(s.ShelfCode)
            e.InCount = GetOrZero(inByKey, e.LocationKey)
            e.OutCount = GetOrZero(outByKey, e.LocationKey)
            result.Entries.Add(e)
            If e.Value > result.MaxValue Then result.MaxValue = e.Value
        Next
        Return result
    End Function

    ''' <summary>回数の多い順に上位n件(同じ間口キーは1件にまとめる)。</summary>
    Public Function TopEntries(result As HeatResult, n As Integer) As List(Of HeatEntry)
        Return result.Entries _
            .GroupBy(Function(x) x.LocationKey) _
            .Select(Function(g) g.First()) _
            .OrderByDescending(Function(x) x.Value) _
            .ThenBy(Function(x) x.LocationKey) _
            .Take(n) _
            .ToList()
    End Function

    Private Function GetOrZero(d As Dictionary(Of String, Integer), key As String) As Integer
        Dim v As Integer = 0
        d.TryGetValue(key, v)
        Return v
    End Function

End Module
