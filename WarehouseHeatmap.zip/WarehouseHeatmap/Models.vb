Option Strict On
Option Explicit On

''' <summary>
''' 棚(ロケーション)マスタ。1レコード = 1つの棚セル(間口 x 段)。
''' 座標は図面系: X=東(m), Y=北(m), Z=高さ(m)。X,Yはセル中心、Zはセル下端の高さ。
''' (Three.js側では x=X, y=Z, z=-Y に変換して表示する)
''' </summary>
Public Class Shelf
    Public Property ShelfCode As String = ""
    Public Property Zone As String = ""
    Public Property RackRow As Integer
    Public Property Bay As Integer
    Public Property Level As Integer
    Public Property X As Double
    Public Property Y As Double
    Public Property Z As Double
    Public Property Width As Double
    Public Property Depth As Double
    Public Property Height As Double

    ''' <summary>間口キー(段を合算して集計するときの単位)。例: A-1-03</summary>
    Public ReadOnly Property BayKey As String
        Get
            Return String.Format("{0}-{1}-{2:00}", Zone, RackRow, Bay)
        End Get
    End Property
End Class

Public Enum MoveKind
    Inbound = 0
    Outbound = 1
End Enum

''' <summary>入出庫履歴の1行。CSV上の MoveType は IN / OUT。</summary>
Public Class StockTransaction
    Public Property TxId As Integer
    Public Property TxDateTime As DateTime
    Public Property ShelfCode As String = ""
    Public Property ItemCode As String = ""
    Public Property ItemName As String = ""
    Public Property MoveType As MoveKind
    Public Property Quantity As Integer
End Class
