# WarehouseHeatmap

工場・倉庫の棚を3Dで表示し、入出庫の回数をヒートマップで見せるデジタルツインのサンプル。
スタンドアローン(サーバー不要)の WinForms アプリ。

## 構成

- `.NET Framework 4.8` / VB.NET / WinForms(UIはデザイナ不使用、`MainForm.vb` にコードで構築)
- 3D表示は `WebView2` に `wwwroot/` の HTML/JS(Three.js)を表示する。C#とJSはJSONメッセージで連携する
- 描画(JS)とデータ集計(C#)を分離している。**集計ロジックはJSに書かない**

| ファイル | 役割 |
|---|---|
| `Program.vb` | エントリポイント |
| `MainForm.vb` | 画面。絞り込み条件・Top10・履歴表・WebView2 の制御 |
| `Models.vb` | `Shelf`(棚マスタ) / `StockTransaction`(入出庫履歴) |
| `DataRepository.vb` | `Data/*.csv` の読み書き(UTF-8 BOM付き) |
| `SampleDataGenerator.vb` | 仮データ生成。実データ接続時はここを置き換える |
| `HeatmapService.vb` | 期間・種別で絞って棚ごとの入出庫**回数**を集計 |
| `WebBridge.vb` | C#⇔JSのJSON組み立て。**メッセージ仕様は先頭コメントが正** |
| `wwwroot/app.js` | Three.js描画。`InstancedMesh` で棚を描画、Raycasterでクリック判定 |
| `wwwroot/lib/` | three.js 0.186.1 と OrbitControls を同梱(オフライン動作のため)。**編集しない** |

## 座標系

棚マスタは図面系(X=東, Y=北, Z=高さ, 単位m, X,Yはセル中心, Zはセル下端)。
Three.js側で `x=X, y=Z, z=-Y` に変換している(`wwwroot/app.js` の `rebuildWorld`)。

## 開発メモ

- `Option Strict On`。新しいコードも型を明示すること
- ビルド: Visual Studio 2022 で `WarehouseHeatmap.vbproj` を開いて F5(NuGetの復元が必要)
- JS単体の確認: `wwwroot` で `python -m http.server` → ブラウザで開く。WebView2の外ではデモデータで表示される
- WebView2 では `https://app.local/` に `wwwroot` を仮想ホストとして割り当てている(ES Modules を使うため)。`file://` で開く方式にはしない
- 配布前に `MainForm.vb` の `AreDevToolsEnabled = True` を `False` にする
- 集計単位は「棚(段ごと)」と「間口(段を合算)」の2つ。真上視点では段が重なって見えるので、合算が向く

## データ

`Data/shelves.csv`(棚マスタ)と `Data/transactions.csv`(入出庫履歴)。列定義は `DataRepository.vb` 先頭のヘッダ定数を参照。
実データに置き換えるときは、同じ列構成のCSVを出力すればそのまま動く。
