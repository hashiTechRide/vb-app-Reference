// 倉庫ヒートマップ(3D表示)
//
// 役割: 「描画」だけを担当する。集計はC#側(HeatmapService.vb)で行い、JSONで受け取る。
//   C# → JS : layout(棚の配置) / heat(棚ごとの回数) / focus(棚の選択)
//   JS → C# : ready(準備完了) / select(クリックした棚)
// メッセージ仕様の詳細は WebBridge.vb の先頭コメントを参照。
//
// 座標: 図面系(X=東, Y=北, Z=高さ) → Three.js(x=X, y=Z, z=-Y) に変換して置く。

import * as THREE from 'three';
import { OrbitControls } from './lib/OrbitControls.js';

// ------------------------------------------------------------------ 状態

const state = {
  shelves: [],            // layout: [{code, bay, zone, row, level, x, y, z, w, d, h}]
  codeIndex: new Map(),   // 棚コード → shelves内のindex
  heat: new Map(),        // 棚コード → {code, key, v, i, o}
  keyIndex: new Map(),    // 集計キー → index配列(同じ間口の棚をまとめて選択するため)
  max: 0,
  merge: false,
  scale: 'sqrt',          // 'linear' | 'sqrt' | 'log'
  selectedKey: '',
};

// ------------------------------------------------------------------ 色(ヒートマップ)

const COLOR_ZERO = new THREE.Color('#cfd5dc');
// 青 → 水色 → 薄黄 → 橙 → 赤 (ColorBrewer RdYlBu を反転)
const STOPS = [
  [0.00, '#2c7bb6'],
  [0.25, '#abd9e9'],
  [0.50, '#ffffbf'],
  [0.75, '#fdae61'],
  [1.00, '#d7191c'],
].map(([t, c]) => [t, new THREE.Color(c)]);

function rampColor(t, target) {
  t = Math.min(1, Math.max(0, t));
  for (let k = 1; k < STOPS.length; k++) {
    if (t <= STOPS[k][0]) {
      const [t0, c0] = STOPS[k - 1];
      const [t1, c1] = STOPS[k];
      return target.copy(c0).lerp(c1, (t - t0) / (t1 - t0));
    }
  }
  return target.copy(STOPS[STOPS.length - 1][1]);
}

// 回数 → 0..1。回数の分布は偏りやすいので尺度を切り替えられるようにしている。
function normalize(v) {
  if (v <= 0 || state.max <= 0) return 0;
  switch (state.scale) {
    case 'sqrt': return Math.sqrt(v / state.max);
    case 'log':  return Math.log1p(v) / Math.log1p(state.max);
    default:     return v / state.max;
  }
}

// 0..1 → 回数(凡例の目盛り用。normalizeの逆変換)
function denormalize(t) {
  switch (state.scale) {
    case 'sqrt': return t * t * state.max;
    case 'log':  return Math.expm1(t * Math.log1p(state.max));
    default:     return t * state.max;
  }
}

// ------------------------------------------------------------------ シーン

const container = document.getElementById('view');
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
container.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xeef1f5);

const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 2000);
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.maxPolarAngle = Math.PI / 2 - 0.02;   // 床の下に潜らない

// 光の強さはThree.jsの物理ベース(r155以降)の値。πで割られるので1より大きめにしている。
scene.add(new THREE.HemisphereLight(0xffffff, 0xb0b8c0, 1.8));
const sun = new THREE.DirectionalLight(0xffffff, 1.6);
sun.position.set(30, 60, 20);
scene.add(sun);

const worldGroup = new THREE.Group();   // layoutごとに作り直す物(床・ラック枠・棚)
scene.add(worldGroup);
let shelfMesh = null;
let bounds = { cx: 0, cz: 0, sx: 60, sz: 40 };
let zoneLabels = [];                    // {el, pos:Vector3}

// 選択ハイライト(半透明の箱 + 枠線)
const selGroup = new THREE.Group();
selGroup.visible = false;
const selFill = new THREE.Mesh(
  new THREE.BoxGeometry(1, 1, 1),
  new THREE.MeshBasicMaterial({ color: 0x111827, transparent: true, opacity: 0.16, depthWrite: false })
);
const selLines = new THREE.Box3Helper(new THREE.Box3(), 0x111827);
selGroup.add(selFill, selLines);
scene.add(selGroup);

function disposeGroup(group) {
  for (const obj of [...group.children]) {
    group.remove(obj);
    obj.traverse((o) => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) o.material.dispose();
    });
  }
}

function rebuildWorld() {
  disposeGroup(worldGroup);
  shelfMesh = null;
  document.getElementById('labels').replaceChildren();
  zoneLabels = [];
  state.codeIndex = new Map(state.shelves.map((s, i) => [s.code, i]));
  if (state.shelves.length === 0) return;

  // ---- 全体の範囲 ----
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const s of state.shelves) {
    minX = Math.min(minX, s.x - s.w / 2); maxX = Math.max(maxX, s.x + s.w / 2);
    minY = Math.min(minY, s.y - s.d / 2); maxY = Math.max(maxY, s.y + s.d / 2);
  }
  const pad = 6;
  minX -= pad; maxX += pad; minY -= pad; maxY += pad;
  bounds = { cx: (minX + maxX) / 2, cz: -(minY + maxY) / 2, sx: maxX - minX, sz: maxY - minY };

  // ---- 床と5mグリッド ----
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(bounds.sx, bounds.sz),
    new THREE.MeshBasicMaterial({ color: 0xfafbfc })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.position.set(bounds.cx, 0, bounds.cz);
  worldGroup.add(floor);

  const pts = [];
  for (let x = Math.ceil(minX / 5) * 5; x <= maxX; x += 5) pts.push(x, 0.02, -minY, x, 0.02, -maxY);
  for (let y = Math.ceil(minY / 5) * 5; y <= maxY; y += 5) pts.push(minX, 0.02, -y, maxX, 0.02, -y);
  const gridGeo = new THREE.BufferGeometry();
  gridGeo.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
  worldGroup.add(new THREE.LineSegments(gridGeo, new THREE.LineBasicMaterial({ color: 0xdde3ea })));

  // ---- 棚セル(InstancedMeshで1回の描画にまとめる。数千棚でも軽い) ----
  shelfMesh = new THREE.InstancedMesh(
    new THREE.BoxGeometry(1, 1, 1),
    new THREE.MeshLambertMaterial({ color: 0xffffff }),
    state.shelves.length
  );
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const p = new THREE.Vector3();
  const sc = new THREE.Vector3();
  state.shelves.forEach((s, i) => {
    p.set(s.x, s.z + s.h / 2, -s.y);
    sc.set(s.w * 0.94, s.h * 0.92, s.d * 0.94);   // 隣と少し隙間を空ける
    m.compose(p, q, sc);
    shelfMesh.setMatrixAt(i, m);
    shelfMesh.setColorAt(i, COLOR_ZERO);
  });
  shelfMesh.instanceMatrix.needsUpdate = true;
  shelfMesh.computeBoundingSphere();   // Raycaster(クリック判定)に必要
  worldGroup.add(shelfMesh);

  // ---- ラック(ゾーン x 列)の外枠 と ゾーン名 ----
  const racks = new Map();   // "A-1" → Box3
  const zones = new Map();   // "A"   → Box3
  const tmp = new THREE.Box3();
  for (const s of state.shelves) {
    tmp.min.set(s.x - s.w / 2, s.z, -s.y - s.d / 2);
    tmp.max.set(s.x + s.w / 2, s.z + s.h, -s.y + s.d / 2);
    const rk = `${s.zone}-${s.row}`;
    if (!racks.has(rk)) racks.set(rk, new THREE.Box3().copy(tmp)); else racks.get(rk).union(tmp);
    if (!zones.has(s.zone)) zones.set(s.zone, new THREE.Box3().copy(tmp)); else zones.get(s.zone).union(tmp);
  }
  for (const box of racks.values()) {
    worldGroup.add(new THREE.Box3Helper(box.clone().expandByScalar(0.05), 0x94a3b8));
  }
  const labelRoot = document.getElementById('labels');
  for (const [zone, box] of zones) {
    const el = document.createElement('div');
    el.className = 'zone-label';
    el.textContent = `ゾーン ${zone}`;
    labelRoot.appendChild(el);
    const c = box.getCenter(new THREE.Vector3());
    // ラックに重ならないよう、ゾーンの手前(南側)の床の上に置く
    zoneLabels.push({ el, pos: new THREE.Vector3(c.x, 0.05, box.max.z + 3) });
  }

  setView(currentView);
}

// ------------------------------------------------------------------ 色の反映

function rebuildKeyIndex() {
  state.keyIndex = new Map();
  for (const h of state.heat.values()) {
    const idx = state.codeIndex.get(h.code);
    if (idx === undefined) continue;
    if (!state.keyIndex.has(h.key)) state.keyIndex.set(h.key, []);
    state.keyIndex.get(h.key).push(idx);
  }
}

function applyHeat() {
  if (!shelfMesh) return;
  const c = new THREE.Color();
  state.shelves.forEach((s, i) => {
    const h = state.heat.get(s.code);
    if (!h || h.v <= 0) c.copy(COLOR_ZERO);
    else rampColor(normalize(h.v), c);
    shelfMesh.setColorAt(i, c);
  });
  shelfMesh.instanceColor.needsUpdate = true;
  updateLegend();
}

function updateLegend() {
  const samples = [];
  const c = new THREE.Color();
  for (let k = 0; k <= 24; k++) samples.push(rampColor(k / 24, c).getStyle());
  document.getElementById('legend-bar').style.background = `linear-gradient(to right, ${samples.join(',')})`;

  const ticks = document.getElementById('legend-ticks');
  ticks.replaceChildren();
  for (const t of [0, 0.25, 0.5, 0.75, 1]) {
    const span = document.createElement('span');
    span.textContent = state.max > 0 ? String(Math.round(denormalize(t))) : '-';
    ticks.appendChild(span);
  }
}

// ------------------------------------------------------------------ 選択・カメラ

function selectKey(key, { fly = false } = {}) {
  state.selectedKey = key;
  const idxs = key ? (state.keyIndex.get(key) || []) : [];
  if (idxs.length === 0) {
    state.selectedKey = '';
    selGroup.visible = false;
    return;
  }
  const box = new THREE.Box3();
  const tmp = new THREE.Box3();
  for (const i of idxs) {
    const s = state.shelves[i];
    tmp.min.set(s.x - s.w / 2, s.z, -s.y - s.d / 2);
    tmp.max.set(s.x + s.w / 2, s.z + s.h, -s.y + s.d / 2);
    box.union(tmp);
  }
  box.expandByScalar(0.15);
  selFill.position.copy(box.getCenter(new THREE.Vector3()));
  selFill.scale.copy(box.getSize(new THREE.Vector3()));
  selLines.box.copy(box);
  selGroup.visible = true;
  if (fly) flyTo(box.getCenter(new THREE.Vector3()));
}

let flight = null;
function flyTo(center) {
  flight = {
    t: 0,
    from: controls.target.clone(),
    to: center.clone(),
    offset: camera.position.clone().sub(controls.target),
  };
}

let currentView = 'iso';
function setView(view) {
  currentView = view;
  flight = null;
  const vFov = THREE.MathUtils.degToRad(camera.fov);
  const needH = (bounds.sz / 2) / Math.tan(vFov / 2);
  const needW = (bounds.sx / 2) / (Math.tan(vFov / 2) * camera.aspect);
  const dist = Math.max(needH, needW) * 1.1;
  controls.target.set(bounds.cx, 0, bounds.cz);
  if (view === 'top') {
    camera.position.set(bounds.cx, dist, bounds.cz + 0.001);
  } else {
    const dir = new THREE.Vector3(0, 0.75, 1).normalize();   // 南側から北を見る斜め視点
    camera.position.copy(controls.target).addScaledVector(dir, dist * 1.05);
  }
  controls.update();
  document.querySelectorAll('[data-view]').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
}

// ------------------------------------------------------------------ ホバー表示とクリック

const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const tip = document.getElementById('tip');
let down = null;

function pick(ev) {
  if (!shelfMesh) return -1;
  const r = renderer.domElement.getBoundingClientRect();
  pointer.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
  raycaster.setFromCamera(pointer, camera);
  const hit = raycaster.intersectObject(shelfMesh)[0];
  return hit && hit.instanceId !== undefined ? hit.instanceId : -1;
}

function row(label, value) {
  const d = document.createElement('div');
  d.className = 'r';
  const a = document.createElement('span'); a.textContent = label;
  const b = document.createElement('span'); b.textContent = value;
  d.append(a, b);
  return d;
}

function showTip(ev, idx) {
  const s = state.shelves[idx];
  const h = state.heat.get(s.code);
  tip.replaceChildren();
  const title = document.createElement('div');
  title.className = 't';
  const name = h ? h.key : s.code;
  title.textContent = state.merge ? `${name}(間口・段を合算)` : name;
  tip.appendChild(title);
  tip.appendChild(row('入庫', `${h ? h.i : 0} 回`));
  tip.appendChild(row('出庫', `${h ? h.o : 0} 回`));
  tip.appendChild(row('合計', `${h ? h.v : 0} 回`));
  tip.style.display = 'block';
  const r = container.getBoundingClientRect();
  tip.style.left = `${Math.min(ev.clientX - r.left + 14, r.width - 180)}px`;
  tip.style.top = `${Math.min(ev.clientY - r.top + 14, r.height - 100)}px`;
}

renderer.domElement.addEventListener('pointermove', (ev) => {
  const idx = pick(ev);
  if (idx < 0) { tip.style.display = 'none'; renderer.domElement.style.cursor = 'default'; return; }
  renderer.domElement.style.cursor = 'pointer';
  showTip(ev, idx);
});
renderer.domElement.addEventListener('pointerleave', () => { tip.style.display = 'none'; });

// ドラッグ(視点移動)とクリックを区別する
renderer.domElement.addEventListener('pointerdown', (ev) => { down = { x: ev.clientX, y: ev.clientY }; });
renderer.domElement.addEventListener('pointerup', (ev) => {
  if (!down) return;
  const moved = Math.hypot(ev.clientX - down.x, ev.clientY - down.y);
  down = null;
  if (moved > 5) return;
  const idx = pick(ev);
  let key = '';
  if (idx >= 0) {
    const h = state.heat.get(state.shelves[idx].code);
    key = h ? h.key : state.shelves[idx].code;
  }
  selectKey(key);
  post({ type: 'select', key: state.selectedKey });
});

// ------------------------------------------------------------------ ツールバー

document.querySelectorAll('[data-view]').forEach((b) => b.addEventListener('click', () => setView(b.dataset.view)));
document.querySelectorAll('[data-scale]').forEach((b) => b.addEventListener('click', () => {
  state.scale = b.dataset.scale;
  document.querySelectorAll('[data-scale]').forEach((x) => x.classList.toggle('active', x === b));
  applyHeat();
}));

// ------------------------------------------------------------------ メッセージ処理

function onMessage(msg) {
  switch (msg.type) {
    case 'layout':
      state.shelves = msg.shelves || [];
      rebuildWorld();
      rebuildKeyIndex();
      applyHeat();           // 先にheatを受け取っていても反映される
      selectKey(state.selectedKey);
      break;
    case 'heat':
      state.heat = new Map((msg.items || []).map((it) => [it.code, it]));
      state.max = msg.max || 0;
      state.merge = !!msg.merge;
      rebuildKeyIndex();
      applyHeat();
      selectKey(state.selectedKey);   // 該当キーが無くなっていれば自動で解除される
      break;
    case 'focus':
      selectKey(msg.key || '', { fly: !!msg.key });
      break;
  }
}

const host = window.chrome && window.chrome.webview ? window.chrome.webview : null;
function post(msg) { if (host) host.postMessage(msg); }

// ------------------------------------------------------------------ デモ(ブラウザ単体で開いたとき用)
// WebView2の外(通常のブラウザ)で開発・確認できるように、C#の SampleDataGenerator と同じ形のデータを作る。

function startDemo() {
  document.getElementById('banner').style.display = 'block';
  const zones = ['A', 'B', 'C', 'D'];
  const ox = [3, 35, 3, 35], oy = [4, 4, 24, 24];
  const zf = [1, 0.6, 0.35, 0.15], lf = [1, 0.6, 0.3];
  let seed = 12345;
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
  const shelves = [], items = [];
  let max = 0;
  zones.forEach((zone, zi) => {
    for (let r = 1; r <= 3; r++) for (let b = 1; b <= 10; b++) for (let lv = 1; lv <= 3; lv++) {
      const bay = `${zone}-${r}-${String(b).padStart(2, '0')}`;
      const code = `${bay}-${lv}`;
      shelves.push({ code, bay, zone, row: r, level: lv, x: ox[zi] + (b - 1) * 2.8 + 1.4, y: oy[zi] + (r - 1) * 5, z: 0.1 + (lv - 1) * 1.5, w: 2.6, d: 1.1, h: 1.2 });
      const w = zf[zi] * lf[lv - 1] * (1 - 0.04 * (b - 1)) * (Math.pow(rnd(), 2) * 2 + 0.05);
      const total = Math.round(w * 140), inn = Math.round(total * 0.35);
      items.push({ code, key: code, v: total, i: inn, o: total - inn });
      max = Math.max(max, total);
    }
  });
  onMessage({ type: 'layout', shelves });
  onMessage({ type: 'heat', max, merge: false, items });
}

// ------------------------------------------------------------------ 描画ループ

function resize() {
  const w = container.clientWidth, h = container.clientHeight;
  if (w === 0 || h === 0) return;
  renderer.setSize(w, h);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}
new ResizeObserver(resize).observe(container);
resize();

const v3 = new THREE.Vector3();
let last = performance.now();
function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.1, (now - last) / 1000);
  last = now;

  if (flight) {
    flight.t = Math.min(1, flight.t + dt * 2.5);
    const k = 1 - Math.pow(1 - flight.t, 3);
    controls.target.lerpVectors(flight.from, flight.to, k);
    camera.position.copy(controls.target).add(flight.offset);
    if (flight.t >= 1) flight = null;
  }
  controls.update();

  // ゾーン名(HTML)を3D位置に追従させる
  const w = container.clientWidth, h = container.clientHeight;
  for (const z of zoneLabels) {
    v3.copy(z.pos).project(camera);
    if (v3.z > 1) { z.el.style.display = 'none'; continue; }
    z.el.style.display = 'block';
    z.el.style.transform = `translate(${(v3.x * 0.5 + 0.5) * w}px, ${(-v3.y * 0.5 + 0.5) * h}px) translate(-50%, -50%)`;
  }
  renderer.render(scene, camera);
}
requestAnimationFrame(loop);

// ------------------------------------------------------------------ 起動

if (host) {
  host.addEventListener('message', (ev) => onMessage(ev.data));
  post({ type: 'ready' });     // C#側が layout → heat の順に送り返す
} else {
  startDemo();
}
