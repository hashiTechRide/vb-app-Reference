Option Strict On
Option Explicit On

Imports System.Collections.Generic
Imports System.Web.Script.Serialization

''' <summary>
''' C# ⇔ JavaScript(3D画面)のメッセージ(JSON)を組み立て・解釈する。
'''
''' C# → JS  (CoreWebView2.PostWebMessageAsJson)
'''   {type:"layout", shelves:[{code,bay,zone,row,level,x,y,z,w,d,h}...]}   棚の配置。起動時に1回
'''   {type:"heat",   max, merge, items:[{code,key,v,i,o}...]}              集計結果。条件変更のたびに送る
'''   {type:"focus",  key}                                                   指定キーの棚を選択(空文字で解除)
'''
''' JS → C#  (window.chrome.webview.postMessage)
'''   {type:"ready"}             画面の準備完了(受け取ったらlayoutとheatを送る)
'''   {type:"select", key}       3D上で棚をクリックした(空文字=選択解除)
''' </summary>
Public Module WebBridge

    Private ReadOnly Serializer As New JavaScriptSerializer() With {.MaxJsonLength = Integer.MaxValue}

    Public Function BuildLayoutJson(shelves As List(Of Shelf)) As String
        Dim items As New List(Of Object)()
        For Each s As Shelf In shelves
            Dim d As New Dictionary(Of String, Object)()
            d("code") = s.ShelfCode
            d("bay") = s.BayKey
            d("zone") = s.Zone
            d("row") = s.RackRow
            d("level") = s.Level
            d("x") = s.X
            d("y") = s.Y
            d("z") = s.Z
            d("w") = s.Width
            d("d") = s.Depth
            d("h") = s.Height
            items.Add(d)
        Next
        Dim msg As New Dictionary(Of String, Object)()
        msg("type") = "layout"
        msg("shelves") = items
        Return Serializer.Serialize(msg)
    End Function

    Public Function BuildHeatJson(result As HeatResult, mergeLevels As Boolean) As String
        Dim items As New List(Of Object)()
        For Each e As HeatEntry In result.Entries
            Dim d As New Dictionary(Of String, Object)()
            d("code") = e.Location.ShelfCode
            d("key") = e.LocationKey
            d("v") = e.Value
            d("i") = e.InCount
            d("o") = e.OutCount
            items.Add(d)
        Next
        Dim msg As New Dictionary(Of String, Object)()
        msg("type") = "heat"
        msg("max") = result.MaxValue
        msg("merge") = mergeLevels
        msg("items") = items
        Return Serializer.Serialize(msg)
    End Function

    Public Function BuildFocusJson(key As String) As String
        Dim msg As New Dictionary(Of String, Object)()
        msg("type") = "focus"
        msg("key") = key
        Return Serializer.Serialize(msg)
    End Function

    Public Function ParseMessage(json As String) As Dictionary(Of String, Object)
        Return TryCast(Serializer.DeserializeObject(json), Dictionary(Of String, Object))
    End Function

    Public Function GetString(msg As Dictionary(Of String, Object), name As String) As String
        Dim v As Object = Nothing
        If msg.TryGetValue(name, v) AndAlso v IsNot Nothing Then Return Convert.ToString(v)
        Return ""
    End Function

End Module
