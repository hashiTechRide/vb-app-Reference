Option Strict On
Option Explicit On

Imports System.Collections.Generic

''' <summary>
''' 仮データ(棚マスタ・入出庫履歴)の生成。
''' 実運用では、この生成部分を「既存の在庫システムからのCSV出力」や「DB読み込み」に置き換える。
''' </summary>
Public Module SampleDataGenerator

    ' ゾーンA~Dを2x2で配置(単位: m)。ゾーンAを出荷口に近い=動きが多い想定にしている。
    Private ReadOnly ZoneNames As String() = {"A", "B", "C", "D"}
    Private ReadOnly ZoneOriginX As Double() = {3.0, 35.0, 3.0, 35.0}
    Private ReadOnly ZoneOriginY As Double() = {4.0, 4.0, 24.0, 24.0}

    ' 入出庫の発生しやすさ(仮): ゾーン / 段(下段ほど多い)
    Private ReadOnly ZoneFactor As Double() = {1.0, 0.6, 0.35, 0.15}
    Private ReadOnly LevelFactor As Double() = {1.0, 0.6, 0.3}

    Private Const RowsPerZone As Integer = 3
    Private Const BaysPerRow As Integer = 10
    Private Const LevelsPerBay As Integer = 3
    Private Const BayPitch As Double = 2.8      ' 間口ピッチ(m)
    Private Const RowPitch As Double = 5.0      ' 列ピッチ(m)。通路幅 = RowPitch - CellDepth
    Private Const LevelPitch As Double = 1.5    ' 段ピッチ(m)
    Private Const CellWidth As Double = 2.6
    Private Const CellDepth As Double = 1.1
    Private Const CellHeight As Double = 1.2

    Private ReadOnly Items As String(,) = {
        {"M-0101", "ボルト M8x30"},
        {"M-0102", "ナット M8"},
        {"M-0201", "ベアリング 6204"},
        {"M-0202", "Oリング P20"},
        {"M-0301", "シール材 SB-3"},
        {"E-0101", "リレー MY2N"},
        {"E-0102", "端子台 TB-12"},
        {"E-0201", "近接センサ PX-5"},
        {"P-0101", "樹脂ケース A型"},
        {"P-0102", "樹脂ケース B型"},
        {"P-0201", "ゴムパッキン 60"},
        {"P-0301", "ラベル 50x30"}
    }

    ''' <summary>4ゾーン x 3列 x 10間口 x 3段 = 360棚。</summary>
    Public Function CreateShelves() As List(Of Shelf)
        Dim list As New List(Of Shelf)()
        For zi As Integer = 0 To ZoneNames.Length - 1
            For r As Integer = 1 To RowsPerZone
                For b As Integer = 1 To BaysPerRow
                    For lv As Integer = 1 To LevelsPerBay
                        Dim s As New Shelf()
                        s.Zone = ZoneNames(zi)
                        s.RackRow = r
                        s.Bay = b
                        s.Level = lv
                        s.ShelfCode = String.Format("{0}-{1}-{2:00}-{3}", s.Zone, r, b, lv)
                        s.X = ZoneOriginX(zi) + (b - 1) * BayPitch + BayPitch / 2.0
                        s.Y = ZoneOriginY(zi) + (r - 1) * RowPitch
                        s.Z = 0.1 + (lv - 1) * LevelPitch
                        s.Width = CellWidth
                        s.Depth = CellDepth
                        s.Height = CellHeight
                        list.Add(s)
                    Next
                Next
            Next
        Next
        Return list
    End Function

    ''' <summary>
    ''' 入出庫履歴(仮)を生成する。平日のみ・8~18時。棚ごとに「動きやすさ」が異なるので、ヒートマップに濃淡が出る。
    ''' </summary>
    ''' <param name="endDate">最終日(この日を含む)</param>
    ''' <param name="days">遡る日数</param>
    ''' <param name="count">生成する件数</param>
    Public Function CreateTransactions(shelves As List(Of Shelf), endDate As DateTime, days As Integer, count As Integer, seed As Integer) As List(Of StockTransaction)
        Dim rnd As New Random(seed)
        Dim n As Integer = shelves.Count
        Dim weights(n - 1) As Double
        Dim cum(n - 1) As Double
        Dim shelfItem(n - 1) As Integer
        Dim total As Double = 0.0

        For i As Integer = 0 To n - 1
            Dim s As Shelf = shelves(i)
            Dim zi As Integer = Array.IndexOf(ZoneNames, s.Zone)
            Dim noise As Double = Math.Pow(rnd.NextDouble(), 2.0) * 2.0 + 0.05   ' 偏りを持たせる
            Dim bayFactor As Double = 1.0 - 0.04 * (s.Bay - 1)                    ' 通路入口側ほど多い
            weights(i) = ZoneFactor(zi) * LevelFactor(s.Level - 1) * bayFactor * noise
            total += weights(i)
            shelfItem(i) = rnd.Next(Items.GetLength(0))                           ' 棚ごとの保管品目
        Next

        ' 累積確率(重み付き抽選用)
        Dim acc As Double = 0.0
        For i As Integer = 0 To n - 1
            acc += weights(i) / total
            cum(i) = acc
        Next
        cum(n - 1) = 1.0

        Dim startDate As DateTime = endDate.Date.AddDays(-(days - 1))
        Dim list As New List(Of StockTransaction)(count)

        For k As Integer = 1 To count
            Dim idx As Integer = Array.BinarySearch(cum, rnd.NextDouble())
            If idx < 0 Then idx = Not idx
            If idx >= n Then idx = n - 1

            Dim day As DateTime = startDate
            Do
                day = startDate.AddDays(rnd.Next(days))
            Loop While day.DayOfWeek = DayOfWeek.Saturday OrElse day.DayOfWeek = DayOfWeek.Sunday

            Dim tx As New StockTransaction()
            tx.TxDateTime = day.AddHours(rnd.Next(8, 18)).AddMinutes(rnd.Next(60)).AddSeconds(rnd.Next(60))
            tx.ShelfCode = shelves(idx).ShelfCode
            tx.ItemCode = Items(shelfItem(idx), 0)
            tx.ItemName = Items(shelfItem(idx), 1)
            If rnd.NextDouble() < 0.35 Then
                tx.MoveType = MoveKind.Inbound
                tx.Quantity = rnd.Next(10, 101)
            Else
                tx.MoveType = MoveKind.Outbound
                tx.Quantity = rnd.Next(1, 31)
            End If
            list.Add(tx)
        Next

        list.Sort(Function(a, b) a.TxDateTime.CompareTo(b.TxDateTime))
        For i As Integer = 0 To list.Count - 1
            list(i).TxId = i + 1
        Next
        Return list
    End Function

End Module
