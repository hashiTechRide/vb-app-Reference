# WarehouseHeatmap — 棚の3Dマップ + 入出庫ヒートマップ(サンプル)

.NET Framework 4.8 / VB.NET の WinForms アプリに、WebView2 + Three.js で3D表示を載せたスタンドアローン構成のサンプルです。
仮の棚(4ゾーン × 3列 × 10間口 × 3段 = 360棚)と、仮の入出庫履歴(約90日・12,000件)が入っています。

![preview](docs/preview.png)

## 動かし方

1. **Visual Studio 2022** で `WarehouseHeatmap.vbproj` を開く(NuGetの復元でWebView2が入ります)
2. F5 で実行

必要なもの: .NET Framework 4.8、Microsoft Edge WebView2 Runtime(Win11は標準搭載。Win10は別途インストール)

## できること

- 3Dで棚を表示。マウスで回転・拡大・移動、ボタンで「斜め/真上」の視点切り替え
- 入出庫の**回数**に応じて棚を色分け(青=少ない → 赤=多い、灰色=0回)
- 絞り込み: 期間 / 入庫のみ・出庫のみ / 集計単位(棚の段ごと・間口で段を合算)
- 色の尺度: 線形 / 平方根 / 対数(回数の偏りが大きいときは平方根か対数が見やすい)
- 棚にマウスを載せると回数、クリックすると右下に入出庫履歴
- 右上のTop10をクリックすると、3D上でその棚へ移動

## ファイル構成

```
WarehouseHeatmap.vbproj
Program.vb              エントリポイント
MainForm.vb             画面(コードでUI構築)
Models.vb               Shelf / StockTransaction
DataRepository.vb       CSV読み書き
SampleDataGenerator.vb  仮データ生成(実データ接続時に置き換える部分)
HeatmapService.vb       入出庫回数の集計
WebBridge.vb            C# ⇔ JS のJSONメッセージ
wwwroot/                3D画面(index.html, app.js, lib/=three.js同梱)
Data/                   shelves.csv, transactions.csv
CLAUDE.md               Claude Code用のプロジェクト説明
```

## データ形式

`Data/` のCSVはUTF-8(BOM付き)で、Excelでそのまま開けます。実データに差し替えるときは同じ列で出力してください。

**shelves.csv**(棚マスタ。座標はメートル。X,Yはセル中心、Zはセル下端の高さ)

```
ShelfCode,Zone,RackRow,Bay,Level,X,Y,Z,Width,Depth,Height
A-1-01-1,A,1,1,1,4.4,4,0.1,2.6,1.1,1.2
```

**transactions.csv**(入出庫履歴。MoveType は IN / OUT)

```
TxId,TxDateTime,ShelfCode,ItemCode,ItemName,MoveType,Quantity
1,2026-07-17 08:01:01,B-1-09-2,P-0102,樹脂ケース B型,IN,53
```

画面の「CSV再読込」でCSVの編集内容が反映されます。「サンプル再生成」は仮データを作り直してCSVを上書きします。

## 仕組み

```
[ C# ]  CSV読込 → 期間/種別で集計(HeatmapService)
   │  PostWebMessageAsJson   layout(棚配置) / heat(棚ごとの回数) / focus(選択)
   ▼
[ JS ]  Three.js で描画(InstancedMesh)。クリックを select で通知
   ▲  postMessage
   │
[ C# ]  選択された棚の履歴を表に表示
```

`wwwroot` は `https://app.local/` という仮想ホストとして WebView2 に割り当てています(ES Modulesを使うため。外部通信は発生しません)。

## 実データへ置き換えるとき

1. 棚マスタ: 図面から棚の座標(X,Y,Z)を起こして `shelves.csv` に。ゾーン・列・間口・段の付け方は自由ですが、`Zone`/`RackRow`/`Bay`/`Level` は表示と集計単位に使うので入れてください
2. 入出庫履歴: 既存システムから `transactions.csv` を出力(または `DataRepository.LoadTransactions` をDB読み込みに差し替え)
3. `ShelfCode` が履歴とマスタで一致していれば、そのままヒートマップに反映されます

## 拡張のアイデア

- 時間帯・曜日別のヒートマップ、数量(個数)ベースの集計
- 柱・壁・設備のモデル追加(Blenderでglb化して `GLTFLoader` で読み込み)
- 棚配置エディタ(クリックで棚を追加・移動してCSV保存)
- 在庫数・滞留日数・品質保留など、別の指標での色分け(`HeatEntry` に項目を足し、`WebBridge` で渡す)

## ライセンス

`wwwroot/lib/` の three.js は MIT ライセンスです(`LICENSE-three.txt` 参照)。
