Option Strict On
Option Explicit On

Imports System.Collections.Generic
Imports System.Data
Imports System.Drawing
Imports System.IO
Imports System.Linq
Imports System.Threading.Tasks
Imports System.Windows.Forms
Imports Microsoft.Web.WebView2.Core
Imports Microsoft.Web.WebView2.WinForms

''' <summary>
''' メイン画面。左 = 3D表示(WebView2 + Three.js)、右 = 回数Top10 と 選択棚の入出庫履歴。
''' UIはデザイナを使わずコードで構築している(サンプルを1ファイルで読めるようにするため)。
''' 3D描画は wwwroot フォルダの HTML/JS が担当し、このフォームは「データの読み込み・集計」と「JSONの受け渡し」だけを行う。
''' </summary>
Public Class MainForm
    Inherits Form

    Private Const HistoryLimit As Integer = 200
    Private Const TopCount As Integer = 10

    ' ---- コントロール ----
    Private ReadOnly _web As New WebView2()
    Private ReadOnly _split As New SplitContainer()
    Private ReadOnly _rightSplit As New SplitContainer()
    Private ReadOnly _dtFrom As New DateTimePicker()
    Private ReadOnly _dtTo As New DateTimePicker()
    Private ReadOnly _cmbMove As New ComboBox()
    Private ReadOnly _cmbUnit As New ComboBox()
    Private ReadOnly _btnReload As New Button()
    Private ReadOnly _btnRegen As New Button()
    Private ReadOnly _gridTop As New DataGridView()
    Private ReadOnly _gridHist As New DataGridView()
    Private ReadOnly _lblTop As New Label()
    Private ReadOnly _lblHist As New Label()
    Private ReadOnly _status As New StatusStrip()
    Private ReadOnly _statusLabel As New ToolStripStatusLabel()

    ' ---- 状態 ----
    Private _shelves As New List(Of Shelf)()
    Private _txs As New List(Of StockTransaction)()
    Private _result As HeatResult
    Private _webReady As Boolean = False
    Private _suppress As Boolean = True        ' 初期化中は再集計しない
    Private _selectedKey As String = ""

    Public Sub New()
        Me.Text = "倉庫ヒートマップ(3D) - 入出庫回数"
        Me.Size = New Size(1300, 820)
        Me.StartPosition = FormStartPosition.CenterScreen
        BuildUi()
    End Sub

    ' ================================================================== UI構築

    Private Sub BuildUi()
        ' ---- 上部バー(絞り込み条件) ----
        Dim bar As New FlowLayoutPanel()
        bar.Dock = DockStyle.Top
        bar.Height = 42
        bar.Padding = New Padding(6, 6, 6, 0)
        bar.WrapContents = False

        _dtFrom.Format = DateTimePickerFormat.Short
        _dtFrom.Width = 105
        _dtTo.Format = DateTimePickerFormat.Short
        _dtTo.Width = 105

        _cmbMove.DropDownStyle = ComboBoxStyle.DropDownList
        _cmbMove.Width = 100
        _cmbMove.Items.AddRange(New Object() {"入庫+出庫", "入庫のみ", "出庫のみ"})
        _cmbMove.SelectedIndex = 0

        _cmbUnit.DropDownStyle = ComboBoxStyle.DropDownList
        _cmbUnit.Width = 120
        _cmbUnit.Items.AddRange(New Object() {"棚(段ごと)", "間口(段を合算)"})
        _cmbUnit.SelectedIndex = 0

        _btnReload.Text = "CSV再読込"
        _btnReload.AutoSize = True
        _btnRegen.Text = "サンプル再生成"
        _btnRegen.AutoSize = True

        bar.Controls.AddRange(New Control() {
            MakeLabel("期間"), _dtFrom, MakeLabel("〜"), _dtTo,
            MakeLabel("種別"), _cmbMove,
            MakeLabel("集計単位"), _cmbUnit,
            _btnReload, _btnRegen})

        ' ---- 左右分割(左=3D、右=表) ----
        _split.Dock = DockStyle.Fill
        _split.FixedPanel = FixedPanel.Panel2
        _web.Dock = DockStyle.Fill
        _split.Panel1.Controls.Add(_web)

        _rightSplit.Dock = DockStyle.Fill
        _rightSplit.Orientation = Orientation.Horizontal
        _split.Panel2.Controls.Add(_rightSplit)

        ' Dock の順序: Fill を先に Add し、Top を後から Add する
        SetupGrid(_gridTop)
        _lblTop.Text = "入出庫回数 Top" & TopCount & "(クリックで3D上に表示)"
        StyleHeader(_lblTop)
        _rightSplit.Panel1.Controls.Add(_gridTop)
        _rightSplit.Panel1.Controls.Add(_lblTop)

        SetupGrid(_gridHist)
        _lblHist.Text = "入出庫履歴: 3D上の棚をクリックすると表示されます"
        StyleHeader(_lblHist)
        _rightSplit.Panel2.Controls.Add(_gridHist)
        _rightSplit.Panel2.Controls.Add(_lblHist)

        ' ---- ステータスバー ----
        _status.Items.Add(_statusLabel)

        Me.Controls.Add(_split)
        Me.Controls.Add(bar)
        Me.Controls.Add(_status)

        _gridTop.DataSource = NewTopTable()
        _gridHist.DataSource = NewHistoryTable()

        AddHandler _dtFrom.ValueChanged, AddressOf OnFilterChanged
        AddHandler _dtTo.ValueChanged, AddressOf OnFilterChanged
        AddHandler _cmbMove.SelectedIndexChanged, AddressOf OnFilterChanged
        AddHandler _cmbUnit.SelectedIndexChanged, AddressOf OnUnitChanged
        AddHandler _btnReload.Click, AddressOf OnReloadClick
        AddHandler _btnRegen.Click, AddressOf OnRegenClick
        AddHandler _gridTop.CellClick, AddressOf OnTopCellClick
    End Sub

    Private Shared Function MakeLabel(text As String) As Label
        Dim lbl As New Label()
        lbl.Text = text
        lbl.AutoSize = True
        lbl.Margin = New Padding(8, 6, 2, 0)
        Return lbl
    End Function

    Private Shared Sub StyleHeader(lbl As Label)
        lbl.Dock = DockStyle.Top
        lbl.Height = 24
        lbl.TextAlign = ContentAlignment.MiddleLeft
        lbl.BackColor = SystemColors.ControlLight
        lbl.Padding = New Padding(4, 0, 0, 0)
    End Sub

    Private Shared Sub SetupGrid(g As DataGridView)
        g.Dock = DockStyle.Fill
        g.ReadOnly = True
        g.AllowUserToAddRows = False
        g.AllowUserToDeleteRows = False
        g.RowHeadersVisible = False
        g.MultiSelect = False
        g.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        g.BackgroundColor = SystemColors.Window
        g.BorderStyle = BorderStyle.None
    End Sub

    Private Shared Function NewTopTable() As DataTable
        Dim t As New DataTable()
        t.Columns.Add("順位", GetType(Integer))
        t.Columns.Add("棚/間口", GetType(String))
        t.Columns.Add("入庫", GetType(Integer))
        t.Columns.Add("出庫", GetType(Integer))
        t.Columns.Add("合計", GetType(Integer))
        Return t
    End Function

    Private Shared Function NewHistoryTable() As DataTable
        Dim t As New DataTable()
        t.Columns.Add("日時", GetType(String))
        t.Columns.Add("棚", GetType(String))
        t.Columns.Add("品目", GetType(String))
        t.Columns.Add("種別", GetType(String))
        t.Columns.Add("数量", GetType(Integer))
        Return t
    End Function

    ' ================================================================== 起動

    Protected Overrides Async Sub OnLoad(e As EventArgs)
        MyBase.OnLoad(e)
        Try
            _split.SplitterDistance = Math.Max(200, _split.Width - 420)
            _rightSplit.SplitterDistance = Math.Max(60, _rightSplit.Height \ 2)

            LoadData()
            Recalculate()          ' この時点では3D画面は未準備なので、表(Top10)だけ更新される
            Await InitWebAsync()
        Catch ex As Exception
            MessageBox.Show(Me, ex.Message, "初期化エラー", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Async Function InitWebAsync() As Task
        Try
            Dim userData As String = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "WarehouseHeatmap", "WebView2")
            Dim env As CoreWebView2Environment = Await CoreWebView2Environment.CreateAsync(Nothing, userData)
            Await _web.EnsureCoreWebView2Async(env)
        Catch ex As Exception
            MessageBox.Show(Me,
                "WebView2 Runtime を初期化できませんでした。" & vbCrLf &
                "Microsoft Edge WebView2 Runtime(Evergreen)をインストールしてください。" & vbCrLf & vbCrLf & ex.Message,
                "WebView2エラー", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try

        Dim wwwroot As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wwwroot")
        Dim core As CoreWebView2 = _web.CoreWebView2
        ' file:// だとES Modulesが読めないため、仮想ホスト名でフォルダを公開する(ネットワークには出ない)
        core.SetVirtualHostNameToFolderMapping("app.local", wwwroot, CoreWebView2HostResourceAccessKind.Allow)
        core.Settings.AreDevToolsEnabled = True        ' F12で開発者ツール。配布時は False に
        core.Settings.IsStatusBarEnabled = False
        AddHandler core.WebMessageReceived, AddressOf OnWebMessage
        core.Navigate("https://app.local/index.html")
    End Function

    ' ================================================================== データ読み込み・集計

    ''' <summary>CSVを読み込み、期間の初期値を「履歴の最初〜最後の日」にする。</summary>
    Private Sub LoadData()
        DataRepository.EnsureSampleData()
        _shelves = DataRepository.LoadShelves()
        _txs = DataRepository.LoadTransactions()

        _suppress = True
        If _txs.Count > 0 Then
            _dtFrom.Value = _txs.Min(Function(t) t.TxDateTime).Date
            _dtTo.Value = _txs.Max(Function(t) t.TxDateTime).Date
        End If
        _suppress = False
    End Sub

    Private Function CurrentFilter() As MoveFilter
        Select Case _cmbMove.SelectedIndex
            Case 1
                Return MoveFilter.InboundOnly
            Case 2
                Return MoveFilter.OutboundOnly
            Case Else
                Return MoveFilter.All
        End Select
    End Function

    Private Function MergeLevels() As Boolean
        Return _cmbUnit.SelectedIndex = 1
    End Function

    Private Sub Recalculate()
        If _suppress OrElse _shelves.Count = 0 Then Return

        _result = HeatmapService.Calculate(_shelves, _txs, _dtFrom.Value, _dtTo.Value, CurrentFilter(), MergeLevels())
        RefreshTop()
        ShowHistory(_selectedKey)
        PushHeat()

        _statusLabel.Text = String.Format("棚 {0:N0} 件 / 履歴 {1:N0} 件(期間・種別で絞込後 {2:N0} 件) / 最大 {3:N0} 回   データ: {4}",
                                          _shelves.Count, _txs.Count, _result.TotalCount, _result.MaxValue,
                                          DataRepository.DataDirectory)
    End Sub

    Private Sub RefreshTop()
        Dim t As DataTable = NewTopTable()
        Dim rank As Integer = 1
        For Each x As HeatEntry In HeatmapService.TopEntries(_result, TopCount)
            If x.Value <= 0 Then Exit For
            t.Rows.Add(rank, x.LocationKey, x.InCount, x.OutCount, x.Value)
            rank += 1
        Next
        _gridTop.DataSource = t
    End Sub

    ''' <summary>選択中の棚(間口)の入出庫履歴を、新しい順に表示する。</summary>
    Private Sub ShowHistory(key As String)
        _selectedKey = key
        Dim t As DataTable = NewHistoryTable()

        If String.IsNullOrEmpty(key) Then
            _lblHist.Text = "入出庫履歴: 3D上の棚をクリックすると表示されます"
            _gridHist.DataSource = t
            Return
        End If

        Dim merge As Boolean = MergeLevels()
        Dim filter As MoveFilter = CurrentFilter()
        Dim keyByShelf As New Dictionary(Of String, String)()
        For Each s As Shelf In _shelves
            keyByShelf(s.ShelfCode) = HeatmapService.KeyOf(s, merge)
        Next

        Dim fromInclusive As DateTime = _dtFrom.Value.Date
        Dim toExclusive As DateTime = _dtTo.Value.Date.AddDays(1)
        Dim rows As List(Of StockTransaction) = _txs.
            Where(Function(x) x.TxDateTime >= fromInclusive AndAlso x.TxDateTime < toExclusive _
                              AndAlso HeatmapService.IsAllowed(filter, x.MoveType) _
                              AndAlso keyByShelf.ContainsKey(x.ShelfCode) _
                              AndAlso keyByShelf(x.ShelfCode) = key).
            OrderByDescending(Function(x) x.TxDateTime).
            Take(HistoryLimit).
            ToList()

        For Each x As StockTransaction In rows
            t.Rows.Add(x.TxDateTime.ToString("yyyy-MM-dd HH:mm"), x.ShelfCode, x.ItemName,
                       If(x.MoveType = MoveKind.Inbound, "入庫", "出庫"), x.Quantity)
        Next
        _lblHist.Text = String.Format("入出庫履歴: {0}(新しい順・最大{1}件)", key, HistoryLimit)
        _gridHist.DataSource = t
    End Sub

    ' ================================================================== 3D画面との連携

    Private Sub PostJson(json As String)
        If Not _webReady OrElse _web.CoreWebView2 Is Nothing Then Return
        _web.CoreWebView2.PostWebMessageAsJson(json)
    End Sub

    Private Sub PushLayout()
        PostJson(WebBridge.BuildLayoutJson(_shelves))
    End Sub

    Private Sub PushHeat()
        If _result Is Nothing Then Return
        PostJson(WebBridge.BuildHeatJson(_result, MergeLevels()))
    End Sub

    Private Sub OnWebMessage(sender As Object, e As CoreWebView2WebMessageReceivedEventArgs)
        Dim msg As Dictionary(Of String, Object) = WebBridge.ParseMessage(e.WebMessageAsJson)
        If msg Is Nothing Then Return

        Select Case WebBridge.GetString(msg, "type")
            Case "ready"
                ' 画面(再)読み込みのたびに来る。layout → heat の順に送る
                _webReady = True
                PushLayout()
                PushHeat()
            Case "select"
                ShowHistory(WebBridge.GetString(msg, "key"))
        End Select
    End Sub

    ' ================================================================== イベント

    Private Sub OnFilterChanged(sender As Object, e As EventArgs)
        Recalculate()
    End Sub

    Private Sub OnUnitChanged(sender As Object, e As EventArgs)
        ' 集計単位が変わると選択キーの意味(棚コード/間口キー)が変わるので、選択は解除する
        _selectedKey = ""
        PostJson(WebBridge.BuildFocusJson(""))
        Recalculate()
    End Sub

    Private Sub OnTopCellClick(sender As Object, e As DataGridViewCellEventArgs)
        If e.RowIndex < 0 Then Return
        Dim key As String = Convert.ToString(_gridTop.Rows(e.RowIndex).Cells(1).Value)
        ShowHistory(key)
        PostJson(WebBridge.BuildFocusJson(key))
    End Sub

    Private Sub OnReloadClick(sender As Object, e As EventArgs)
        ReloadFromCsv()
    End Sub

    Private Sub OnRegenClick(sender As Object, e As EventArgs)
        Dim answer As DialogResult = MessageBox.Show(Me,
            "Data フォルダの shelves.csv / transactions.csv を、新しい仮データで上書きします。よろしいですか?",
            "サンプルデータ再生成", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If answer <> DialogResult.Yes Then Return
        Try
            DataRepository.RegenerateSampleData(Environment.TickCount)
            ReloadFromCsv()
        Catch ex As Exception
            MessageBox.Show(Me, ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ''' <summary>CSVを読み直して、棚の配置と集計をやり直す。CSVを外部で編集したあとに使う。</summary>
    Private Sub ReloadFromCsv()
        Try
            _selectedKey = ""
            LoadData()
            PushLayout()           ' 棚の配置が変わっている可能性があるので先に送る
            Recalculate()
            PostJson(WebBridge.BuildFocusJson(""))
        Catch ex As Exception
            MessageBox.Show(Me, ex.Message, "CSV読み込みエラー", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class
