Option Strict On
Option Explicit On

Imports System.Collections.Generic
Imports System.Globalization
Imports System.IO
Imports System.Text

''' <summary>
''' CSVの読み書き。データは exe と同じ場所の Data フォルダに置く(UTF-8 BOM付き。Excelでそのまま開ける)。
'''   shelves.csv       棚マスタ
'''   transactions.csv  入出庫履歴
''' </summary>
Public Module DataRepository

    Private ReadOnly Inv As CultureInfo = CultureInfo.InvariantCulture
    Private ReadOnly Utf8Bom As New UTF8Encoding(True)

    Private Const ShelvesHeader As String = "ShelfCode,Zone,RackRow,Bay,Level,X,Y,Z,Width,Depth,Height"
    Private Const TransactionsHeader As String = "TxId,TxDateTime,ShelfCode,ItemCode,ItemName,MoveType,Quantity"
    Private Const DateFormat As String = "yyyy-MM-dd HH:mm:ss"

    Public ReadOnly Property DataDirectory As String
        Get
            Return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data")
        End Get
    End Property

    Public ReadOnly Property ShelvesPath As String
        Get
            Return Path.Combine(DataDirectory, "shelves.csv")
        End Get
    End Property

    Public ReadOnly Property TransactionsPath As String
        Get
            Return Path.Combine(DataDirectory, "transactions.csv")
        End Get
    End Property

    ''' <summary>CSVが無ければ仮データを生成して保存する。</summary>
    Public Sub EnsureSampleData()
        If File.Exists(ShelvesPath) AndAlso File.Exists(TransactionsPath) Then Return
        RegenerateSampleData(20261015)
    End Sub

    ''' <summary>仮データを作り直してCSVに上書き保存する。</summary>
    Public Sub RegenerateSampleData(seed As Integer)
        Dim shelves As List(Of Shelf) = SampleDataGenerator.CreateShelves()
        Dim txs As List(Of StockTransaction) = SampleDataGenerator.CreateTransactions(shelves, DateTime.Today.AddDays(-1), 90, 12000, seed)
        Directory.CreateDirectory(DataDirectory)
        SaveShelves(shelves)
        SaveTransactions(txs)
    End Sub

    ' ---------------------------------------------------------------- 保存

    Public Sub SaveShelves(shelves As List(Of Shelf))
        Dim sb As New StringBuilder()
        sb.AppendLine(ShelvesHeader)
        For Each s As Shelf In shelves
            sb.AppendLine(String.Join(",", New String() {
                Esc(s.ShelfCode), Esc(s.Zone),
                s.RackRow.ToString(Inv), s.Bay.ToString(Inv), s.Level.ToString(Inv),
                Num(s.X), Num(s.Y), Num(s.Z), Num(s.Width), Num(s.Depth), Num(s.Height)}))
        Next
        File.WriteAllText(ShelvesPath, sb.ToString(), Utf8Bom)
    End Sub

    Public Sub SaveTransactions(txs As List(Of StockTransaction))
        Dim sb As New StringBuilder()
        sb.AppendLine(TransactionsHeader)
        For Each t As StockTransaction In txs
            sb.AppendLine(String.Join(",", New String() {
                t.TxId.ToString(Inv),
                t.TxDateTime.ToString(DateFormat, Inv),
                Esc(t.ShelfCode), Esc(t.ItemCode), Esc(t.ItemName),
                If(t.MoveType = MoveKind.Inbound, "IN", "OUT"),
                t.Quantity.ToString(Inv)}))
        Next
        File.WriteAllText(TransactionsPath, sb.ToString(), Utf8Bom)
    End Sub

    ' ---------------------------------------------------------------- 読み込み

    Public Function LoadShelves() As List(Of Shelf)
        Dim list As New List(Of Shelf)()
        Dim lines As String() = File.ReadAllLines(ShelvesPath, Encoding.UTF8)
        For i As Integer = 1 To lines.Length - 1          ' 0行目はヘッダ
            If String.IsNullOrWhiteSpace(lines(i)) Then Continue For
            Dim f As List(Of String) = ParseCsvLine(lines(i))
            If f.Count < 11 Then
                Throw New InvalidDataException(String.Format("shelves.csv {0}行目: 列数が足りません(11列必要)。", i + 1))
            End If
            Dim s As New Shelf()
            s.ShelfCode = f(0)
            s.Zone = f(1)
            s.RackRow = Integer.Parse(f(2), Inv)
            s.Bay = Integer.Parse(f(3), Inv)
            s.Level = Integer.Parse(f(4), Inv)
            s.X = Double.Parse(f(5), NumberStyles.Float, Inv)
            s.Y = Double.Parse(f(6), NumberStyles.Float, Inv)
            s.Z = Double.Parse(f(7), NumberStyles.Float, Inv)
            s.Width = Double.Parse(f(8), NumberStyles.Float, Inv)
            s.Depth = Double.Parse(f(9), NumberStyles.Float, Inv)
            s.Height = Double.Parse(f(10), NumberStyles.Float, Inv)
            list.Add(s)
        Next
        Return list
    End Function

    Public Function LoadTransactions() As List(Of StockTransaction)
        Dim list As New List(Of StockTransaction)()
        Dim lines As String() = File.ReadAllLines(TransactionsPath, Encoding.UTF8)
        For i As Integer = 1 To lines.Length - 1
            If String.IsNullOrWhiteSpace(lines(i)) Then Continue For
            Dim f As List(Of String) = ParseCsvLine(lines(i))
            If f.Count < 7 Then
                Throw New InvalidDataException(String.Format("transactions.csv {0}行目: 列数が足りません(7列必要)。", i + 1))
            End If
            Dim t As New StockTransaction()
            t.TxId = Integer.Parse(f(0), Inv)
            t.TxDateTime = DateTime.ParseExact(f(1), DateFormat, Inv)
            t.ShelfCode = f(2)
            t.ItemCode = f(3)
            t.ItemName = f(4)
            t.MoveType = If(String.Equals(f(5), "IN", StringComparison.OrdinalIgnoreCase), MoveKind.Inbound, MoveKind.Outbound)
            t.Quantity = Integer.Parse(f(6), Inv)
            list.Add(t)
        Next
        Return list
    End Function

    ' ---------------------------------------------------------------- CSV補助

    Private Function Num(v As Double) As String
        Return v.ToString("0.###", Inv)
    End Function

    Private Function Esc(s As String) As String
        If s.IndexOfAny(New Char() {","c, """"c, ControlChars.Cr, ControlChars.Lf}) >= 0 Then
            Return """" & s.Replace("""", """""") & """"
        End If
        Return s
    End Function

    ''' <summary>ダブルクォート対応の最小限のCSV1行パーサ(行内改行は非対応)。</summary>
    Private Function ParseCsvLine(line As String) As List(Of String)
        Dim result As New List(Of String)()
        Dim sb As New StringBuilder()
        Dim inQuotes As Boolean = False
        Dim i As Integer = 0
        While i < line.Length
            Dim c As Char = line(i)
            If inQuotes Then
                If c = """"c Then
                    If i + 1 < line.Length AndAlso line(i + 1) = """"c Then
                        sb.Append(""""c)
                        i += 1
                    Else
                        inQuotes = False
                    End If
                Else
                    sb.Append(c)
                End If
            ElseIf c = """"c Then
                inQuotes = True
            ElseIf c = ","c Then
                result.Add(sb.ToString())
                sb.Clear()
            Else
                sb.Append(c)
            End If
            i += 1
        End While
        result.Add(sb.ToString())
        Return result
    End Function

End Module
