// Q6: Server Component内にClient Componentを含む構成

// ---- FavoriteButton.tsx (Client Component) ----
"use client";

import { useState } from "react";

export function FavoriteButton({ userId }: { userId: number }) {
  const [isFavorite, setIsFavorite] = useState(false);

  return (
    <button onClick={() => setIsFavorite(!isFavorite)}>
      {isFavorite ? "★ お気に入り解除" : "☆ お気に入り"}
    </button>
  );
}

// ---- app/users/page.tsx (Server Component) ----
// import { FavoriteButton } from "@/components/FavoriteButton";

interface User {
  id: number;
  name: string;
  email: string;
}

export default async function UsersPage() {
  const response = await fetch("https://jsonplaceholder.typicode.com/users");
  const users: User[] = await response.json();

  return (
    <div>
      <h1>ユーザー一覧</h1>
      <ul>
        {users.map((user) => (
          <li key={user.id}>
            {user.name}
            {/* Client Component をServer Component内で使用 */}
            <FavoriteButton userId={user.id} />
          </li>
        ))}
      </ul>
    </div>
  );
}
