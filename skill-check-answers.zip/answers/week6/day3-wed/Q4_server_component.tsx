// Q4: Server Component - APIからデータ取得して表示
// app/users/page.tsx (Server Component - デフォルト)

interface User {
  id: number;
  name: string;
  email: string;
}

export default async function UsersPage() {
  const response = await fetch("https://jsonplaceholder.typicode.com/users");
  const users: User[] = await response.json();

  return (
    <div>
      <h1>ユーザー一覧</h1>
      <ul>
        {users.map((user) => (
          <li key={user.id}>
            {user.name} ({user.email})
          </li>
        ))}
      </ul>
    </div>
  );
}
