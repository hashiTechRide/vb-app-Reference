// Q5: loading.tsx
// app/users/loading.tsx

export default function Loading() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <p className="text-lg text-gray-500">読み込み中...</p>
    </div>
  );
}
