// Q4: Server Component で外部APIからユーザー一覧取得
// app/users/page.tsx

interface User {
  id: number;
  name: string;
  email: string;
}

export default async function UsersPage() {
  const response = await fetch("https://jsonplaceholder.typicode.com/users", {
    // Next.js App Router ではデフォルトで fetch 結果がキャッシュされる（静的レンダリング）
    // 動的にしたい場合: cache: "no-store"
  });

  if (!response.ok) {
    throw new Error("ユーザーデータの取得に失敗しました");
  }

  const users: User[] = await response.json();

  return (
    <div>
      <h1>ユーザー一覧</h1>
      <ul>
        {users.map((user) => (
          <li key={user.id}>
            <strong>{user.name}</strong> - {user.email}
          </li>
        ))}
      </ul>
    </div>
  );
}
