"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

// Q4: 現在のパスに応じてアクティブ項目のスタイルを変える
const navItems = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export default function Navigation() {
  const pathname = usePathname();

  return (
    <nav className="flex gap-4 p-4 bg-gray-800">
      {navItems.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          className={`px-3 py-2 rounded-lg ${
            pathname === item.href
              ? "bg-blue-500 text-white"
              : "text-gray-300 hover:text-white"
          }`}
        >
          {item.label}
        </Link>
      ))}
    </nav>
  );
}

// Q5: /dashboard 配下に独自サイドバーレイアウト
// フォルダ構成:
// app/
// ├── layout.tsx           ← ルートレイアウト
// └── dashboard/
//     ├── layout.tsx        ← ダッシュボード専用レイアウト（サイドバー付き）
//     ├── page.tsx          ← /dashboard
//     └── settings/
//         └── page.tsx      ← /dashboard/settings

// app/dashboard/layout.tsx の内容:
// export default function DashboardLayout({ children }: { children: React.ReactNode }) {
//   return (
//     <div className="flex">
//       <aside className="w-64 bg-gray-900 text-white min-h-screen p-4">
//         <h2 className="text-lg font-bold mb-4">Dashboard</h2>
//         <nav className="flex flex-col gap-2">
//           <Link href="/dashboard">概要</Link>
//           <Link href="/dashboard/settings">設定</Link>
//         </nav>
//       </aside>
//       <main className="flex-1 p-6">{children}</main>
//     </div>
//   );
// }
