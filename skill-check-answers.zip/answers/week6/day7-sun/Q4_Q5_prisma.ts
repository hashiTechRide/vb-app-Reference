// Q4: Prismaスキーマ定義
// prisma/schema.prisma の内容:
/*
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id        Int      @id @default(autoincrement())
  name      String
  email     String   @unique
  createdAt DateTime @default(now())
}
*/

// Q5: Prisma Client での CRUD 操作
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// 全ユーザー取得
async function getAllUsers() {
  return await prisma.user.findMany();
}

// 1件取得
async function getUserById(id: number) {
  return await prisma.user.findUnique({
    where: { id },
  });
}

// 新規作成
async function createUser(name: string, email: string) {
  return await prisma.user.create({
    data: { name, email },
  });
}

// 更新
async function updateUser(id: number, name: string) {
  return await prisma.user.update({
    where: { id },
    data: { name },
  });
}

// 削除
async function deleteUser(id: number) {
  return await prisma.user.delete({
    where: { id },
  });
}

export { prisma, getAllUsers, getUserById, createUser, updateUser, deleteUser };
