// ===== Day 1 (3/23) Next.js概要 + ルーティング =====

// Q4: Home, About, Contact の3ページのフォルダ構成
// app/
// ├── page.tsx          ← Home（/）
// ├── about/
// │   └── page.tsx      ← About（/about）
// ├── contact/
// │   └── page.tsx      ← Contact（/contact）
// └── layout.tsx        ← ルートレイアウト

// Q5: 共通ヘッダーとフッターを含むルートレイアウト
// app/layout.tsx
import { ReactNode } from "react";

export const metadata = {
  title: "My App",
  description: "Next.js App",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ja">
      <body>
        <header style={{ background: "#1f2937", color: "white", padding: "16px" }}>
          <nav>
            <a href="/">Home</a> | <a href="/about">About</a> | <a href="/contact">Contact</a>
          </nav>
        </header>
        <main style={{ minHeight: "80vh", padding: "20px" }}>{children}</main>
        <footer style={{ background: "#1f2937", color: "white", padding: "16px", textAlign: "center" }}>
          &copy; 2025 My App
        </footer>
      </body>
    </html>
  );
}
