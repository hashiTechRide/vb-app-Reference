import { createClient } from "@supabase/supabase-js";

// Q1: Supabaseクライアントの初期化
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Q2: todosテーブルから全件取得
async function getAllTodos() {
  const { data, error } = await supabase.from("todos").select("*");

  if (error) {
    console.error("取得エラー:", error.message);
    return [];
  }
  return data;
}

// Q3: 新しいレコードをINSERT
async function addTodo(title: string) {
  const { data, error } = await supabase
    .from("todos")
    .insert({ title, completed: false })
    .select();

  if (error) {
    console.error("追加エラー:", error.message);
    return null;
  }
  return data;
}

// Q4: Next.js Server ComponentからSupabaseデータ取得・一覧表示
// app/todos/page.tsx
// import { createClient } from "@supabase/supabase-js";

interface Todo {
  id: number;
  title: string;
  completed: boolean;
  created_at: string;
}

export default async function TodosPage() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  const { data: todos, error } = await supabase
    .from("todos")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    return <p>エラー: {error.message}</p>;
  }

  return (
    <div>
      <h1>TODOリスト</h1>
      <ul>
        {(todos as Todo[]).map((todo) => (
          <li key={todo.id}>
            {todo.completed ? "✅" : "⬜"} {todo.title}
          </li>
        ))}
      </ul>
    </div>
  );
}

export { supabase, getAllTodos, addTodo };
