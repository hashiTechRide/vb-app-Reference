// Q4: Server Action でTODO追加（zodバリデーション含む）
// app/actions/todo.ts
"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const todoSchema = z.object({
  title: z.string().min(1, "タイトルは必須です").max(100, "100文字以内で入力してください"),
});

export async function addTodo(formData: FormData) {
  const rawTitle = formData.get("title");

  const result = todoSchema.safeParse({ title: rawTitle });
  if (!result.success) {
    return { error: result.error.flatten().fieldErrors.title?.[0] };
  }

  await prisma.todo.create({
    data: { title: result.data.title, completed: false },
  });

  // Q5: revalidatePath でデータ再取得
  revalidatePath("/todos");
  return { success: true };
}

// フォームコンポーネント（Client Component側）
// "use client";
// import { addTodo } from "@/app/actions/todo";
//
// export function TodoForm() {
//   return (
//     <form action={addTodo}>
//       <input name="title" placeholder="新しいTODO" />
//       <button type="submit">追加</button>
//     </form>
//   );
// }
