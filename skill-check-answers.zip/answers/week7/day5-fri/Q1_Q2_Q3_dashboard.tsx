// Q1: ダッシュボードアプリのフォルダ構成
/*
app/
├── layout.tsx                 ← ルートレイアウト
├── page.tsx                   ← トップページ
├── login/
│   └── page.tsx               ← ログインページ
├── dashboard/
│   ├── layout.tsx             ← ダッシュボード専用レイアウト（サイドバー付き）
│   ├── page.tsx               ← ダッシュボードトップ
│   ├── loading.tsx            ← ローディング表示
│   ├── error.tsx              ← エラー表示
│   ├── users/
│   │   ├── page.tsx           ← ユーザー一覧
│   │   └── [id]/
│   │       └── page.tsx       ← ユーザー詳細
│   └── settings/
│       └── page.tsx           ← 設定
├── api/
│   └── users/
│       ├── route.ts           ← GET/POST
│       └── [id]/
│           └── route.ts       ← GET/PUT/DELETE
└── components/
    ├── Sidebar.tsx            ← サイドバーナビゲーション
    ├── KpiCard.tsx            ← KPIカード
    └── DataTable.tsx          ← テーブル
*/

// Q2: サイドバー + メインコンテンツのレイアウト
// app/dashboard/layout.tsx
import Link from "next/link";

const sidebarItems = [
  { href: "/dashboard", label: "ダッシュボード", icon: "📊" },
  { href: "/dashboard/users", label: "ユーザー", icon: "👥" },
  { href: "/dashboard/settings", label: "設定", icon: "⚙️" },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <aside className="w-64 bg-gray-900 text-white p-4">
        <h2 className="text-xl font-bold mb-6">管理画面</h2>
        <nav className="flex flex-col gap-2">
          {sidebarItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-700"
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>
      </aside>
      <main className="flex-1 bg-gray-50 p-6">{children}</main>
    </div>
  );
}

// Q3: KPIカードコンポーネント
interface KpiCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: "positive" | "negative" | "neutral";
}

function KpiCard({ title, value, change, changeType = "neutral" }: KpiCardProps) {
  const changeColor =
    changeType === "positive"
      ? "text-green-600"
      : changeType === "negative"
        ? "text-red-600"
        : "text-gray-500";

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <p className="text-sm text-gray-500">{title}</p>
      <p className="text-3xl font-bold mt-2">{value}</p>
      {change && <p className={`text-sm mt-1 ${changeColor}`}>{change}</p>}
    </div>
  );
}

// ダッシュボードトップページ
// app/dashboard/page.tsx
function DashboardPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">ダッシュボード</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard title="総ユーザー数" value="1,234" change="+12%" changeType="positive" />
        <KpiCard title="月間売上" value="¥5,678,000" change="+8.5%" changeType="positive" />
        <KpiCard title="アクティブ率" value="85.3%" change="-2.1%" changeType="negative" />
        <KpiCard title="新規登録" value="56" change="前月と同じ" changeType="neutral" />
      </div>
    </div>
  );
}

export { KpiCard, DashboardPage };
