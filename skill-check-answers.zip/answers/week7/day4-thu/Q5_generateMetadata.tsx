// Q5: generateMetadata - 動的メタデータ
// app/posts/[id]/page.tsx
import { Metadata } from "next";

interface Post {
  id: number;
  title: string;
  body: string;
}

interface PageProps {
  params: Promise<{ id: string }>;
}

// 動的にページタイトルを設定
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const response = await fetch(
    `https://jsonplaceholder.typicode.com/posts/${id}`
  );
  const post: Post = await response.json();

  return {
    title: post.title,
    description: post.body.slice(0, 160),
  };
}

export default async function PostPage({ params }: PageProps) {
  const { id } = await params;
  const response = await fetch(
    `https://jsonplaceholder.typicode.com/posts/${id}`
  );
  const post: Post = await response.json();

  return (
    <article>
      <h1>{post.title}</h1>
      <p>{post.body}</p>
    </article>
  );
}
