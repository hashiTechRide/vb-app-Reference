// Q4 & Q5: middleware.ts - 認証チェック + リダイレクト
import { NextRequest, NextResponse } from "next/server";

export function middleware(request: NextRequest) {
  // 認証トークンをCookieから取得
  const token = request.cookies.get("auth-token")?.value;

  // トークンがなければ /login にリダイレクト
  if (!token) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  return NextResponse.next();
}

// Q5: matcher で特定のパスにのみ適用
export const config = {
  matcher: ["/dashboard/:path*"],
  // /dashboard 配下の全てのパスに適用
  // /dashboard, /dashboard/settings, /dashboard/users 等
};
