// ===== Q10: /posts/[id] 動的ルートページ =====
// app/posts/[id]/page.tsx

interface Post {
  id: number;
  title: string;
  body: string;
}

export default async function PostPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const res = await fetch(`https://jsonplaceholder.typicode.com/posts/${id}`);
  const post: Post = await res.json();

  return (
    <article>
      <h1>{post.title}</h1>
      <p>{post.body}</p>
    </article>
  );
}

// ===== Q11: Server Action → DB保存 → revalidatePath =====
// app/actions/post.ts
"use server";

import { revalidatePath } from "next/cache";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function createPost(formData: FormData) {
  const title = formData.get("title") as string;
  const body = formData.get("body") as string;

  await prisma.post.create({
    data: { title, body, authorId: 1 },
  });

  revalidatePath("/posts");
}

// ===== Q12: Route Handler GET + POST =====
// app/api/posts/route.ts
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  const posts = await prisma.post.findMany();
  return NextResponse.json(posts);
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const post = await prisma.post.create({ data: body });
  return NextResponse.json(post, { status: 201 });
}

// ===== Q13: middleware.ts 認証チェック + リダイレクト =====
// middleware.ts
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
  const token = request.cookies.get("auth-token")?.value;
  if (!token) {
    return NextResponse.redirect(new URL("/login", request.url));
  }
  return NextResponse.next();
}

export const config = { matcher: ["/dashboard/:path*"] };

// ===== Q15: Prisma User + Post リレーション + CRUD =====
/*
// prisma/schema.prisma
model User {
  id    Int    @id @default(autoincrement())
  name  String
  email String @unique
  posts Post[]
}

model Post {
  id       Int    @id @default(autoincrement())
  title    String
  body     String
  author   User   @relation(fields: [authorId], references: [id])
  authorId Int
}
*/

// CRUD操作
async function crudExample() {
  // Create
  const user = await prisma.user.create({
    data: {
      name: "太郎",
      email: "taro@example.com",
      posts: { create: { title: "初投稿", body: "Hello!" } },
    },
    include: { posts: true },
  });

  // Read (with relation)
  const users = await prisma.user.findMany({ include: { posts: true } });

  // Update
  await prisma.user.update({
    where: { id: 1 },
    data: { name: "次郎" },
  });

  // Delete
  await prisma.post.deleteMany({ where: { authorId: 1 } });
  await prisma.user.delete({ where: { id: 1 } });
}
