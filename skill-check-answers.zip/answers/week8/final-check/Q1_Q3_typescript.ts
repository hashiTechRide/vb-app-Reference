// ===== 8週間 最終総合チェック コード回答 =====

// --- TypeScript ---

// Q1: ジェネリック型 ApiResponse<T>
type ApiResponse<T> = {
  data: T;
  status: number;
  message: string;
};

interface User {
  id: number;
  name: string;
  email: string;
}

const response: ApiResponse<User[]> = {
  data: [{ id: 1, name: "太郎", email: "taro@example.com" }],
  status: 200,
  message: "Success",
};

// Q3: Discriminated Union - Shape面積計算
type Circle = { kind: "circle"; radius: number };
type Rectangle = { kind: "rectangle"; width: number; height: number };
type Shape = Circle | Rectangle;

function calculateArea(shape: Shape): number {
  switch (shape.kind) {
    case "circle":
      return Math.PI * shape.radius ** 2;
    case "rectangle":
      return shape.width * shape.height;
  }
}

export {};
