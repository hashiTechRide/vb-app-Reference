"use client";

import React, { useState } from "react";

// Q1: 汎用テーブルコンポーネント
interface DataTableProps<T> {
  headers: { key: keyof T; label: string }[];
  data: T[];
  pageSize?: number;
}

function DataTable<T extends Record<string, any>>({
  headers,
  data,
  pageSize = 5,
}: DataTableProps<T>) {
  // Q2: ソート機能
  const [sortKey, setSortKey] = useState<keyof T | null>(null);
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");

  // Q3: ページネーション
  const [currentPage, setCurrentPage] = useState(1);

  const handleSort = (key: keyof T) => {
    if (sortKey === key) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortOrder("asc");
    }
    setCurrentPage(1);
  };

  // ソート処理
  const sortedData = [...data].sort((a, b) => {
    if (!sortKey) return 0;
    const aVal = a[sortKey];
    const bVal = b[sortKey];
    if (aVal < bVal) return sortOrder === "asc" ? -1 : 1;
    if (aVal > bVal) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });

  // ページネーション処理
  const totalPages = Math.ceil(sortedData.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const pagedData = sortedData.slice(startIndex, startIndex + pageSize);

  return (
    <div>
      <table className="w-full border-collapse">
        <thead>
          <tr>
            {headers.map((header) => (
              <th
                key={String(header.key)}
                onClick={() => handleSort(header.key)}
                className="border p-2 bg-gray-100 cursor-pointer hover:bg-gray-200 text-left"
              >
                {header.label}
                {sortKey === header.key && (sortOrder === "asc" ? " ▲" : " ▼")}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {pagedData.map((row, index) => (
            <tr key={index} className="hover:bg-gray-50">
              {headers.map((header) => (
                <td key={String(header.key)} className="border p-2">
                  {String(row[header.key])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      {/* ページネーション UI */}
      <div className="flex items-center justify-center gap-2 mt-4">
        <button
          onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
          disabled={currentPage === 1}
          className="px-3 py-1 border rounded disabled:opacity-50"
        >
          前へ
        </button>
        {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
          <button
            key={page}
            onClick={() => setCurrentPage(page)}
            className={`px-3 py-1 border rounded ${
              page === currentPage ? "bg-blue-500 text-white" : ""
            }`}
          >
            {page}
          </button>
        ))}
        <button
          onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
          disabled={currentPage === totalPages}
          className="px-3 py-1 border rounded disabled:opacity-50"
        >
          次へ
        </button>
      </div>
    </div>
  );
}

export default DataTable;
