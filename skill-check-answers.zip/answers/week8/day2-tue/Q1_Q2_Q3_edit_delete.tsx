// Q1: 編集画面で既存データを初期値として表示
// app/users/[id]/edit/page.tsx
import { PrismaClient } from "@prisma/client";
import { EditUserForm } from "./EditUserForm";
import { notFound } from "next/navigation";

const prisma = new PrismaClient();

interface PageProps {
  params: Promise<{ id: string }>;
}

export default async function EditUserPage({ params }: PageProps) {
  const { id } = await params;
  const user = await prisma.user.findUnique({
    where: { id: parseInt(id) },
  });

  if (!user) notFound();

  return (
    <div>
      <h1>ユーザー編集</h1>
      <EditUserForm user={user} />
    </div>
  );
}

// Q2: Server Action で更新 + リダイレクト
// app/actions/user.ts
"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function updateUser(formData: FormData) {
  const id = Number(formData.get("id"));
  const name = formData.get("name") as string;
  const email = formData.get("email") as string;

  await prisma.user.update({
    where: { id },
    data: { name, email },
  });

  revalidatePath("/users");
  redirect("/users");
}

// Q3: 削除ボタン + 確認ダイアログ
// components/DeleteButton.tsx (Client Component)
"use client";

import { deleteUser } from "@/app/actions/user";

export function DeleteButton({ userId }: { userId: number }) {
  const handleDelete = async () => {
    const confirmed = window.confirm("本当に削除しますか？");
    if (!confirmed) return;

    const formData = new FormData();
    formData.set("id", String(userId));
    await deleteUser(formData);
  };

  return (
    <button
      onClick={handleDelete}
      className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-700"
    >
      削除
    </button>
  );
}

// Server Action: deleteUser
export async function deleteUserAction(formData: FormData) {
  "use server";
  const id = Number(formData.get("id"));
  await prisma.user.delete({ where: { id } });
  revalidatePath("/users");
}
