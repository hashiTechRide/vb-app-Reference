import React, { ReactNode } from "react";

// Q4: UserCard コンポーネント
type UserCardProps = {
  name: string;
  age: number;
  avatarUrl?: string;
};

const UserCard = ({ name, age, avatarUrl }: UserCardProps) => {
  return (
    <div className="user-card">
      {avatarUrl && <img src={avatarUrl} alt={`${name}のアバター`} />}
      <h3>{name}</h3>
      <p>{age}歳</p>
    </div>
  );
};

// Q5: children を受け取る Card コンポーネント
type CardProps = {
  children: ReactNode;
};

const Card = ({ children }: CardProps) => {
  return <div className="card">{children}</div>;
};

// Q6: Button コンポーネント
type ButtonProps = {
  label: string;
  variant: "primary" | "secondary" | "danger";
  onClick: () => void;
};

const Button = ({ label, variant, onClick }: ButtonProps) => {
  const baseStyle: React.CSSProperties = {
    padding: "8px 16px",
    borderRadius: "4px",
    border: "none",
    cursor: "pointer",
    color: "white",
    fontWeight: "bold",
  };

  const variantColors: Record<ButtonProps["variant"], string> = {
    primary: "#3b82f6",
    secondary: "#6b7280",
    danger: "#ef4444",
  };

  return (
    <button
      style={{ ...baseStyle, backgroundColor: variantColors[variant] }}
      onClick={onClick}
    >
      {label}
    </button>
  );
};

export { UserCard, Card, Button };
