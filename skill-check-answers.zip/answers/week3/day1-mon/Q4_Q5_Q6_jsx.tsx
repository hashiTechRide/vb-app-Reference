import React from "react";

// Q4: プロフィールカードコンポーネント
const ProfileCard = () => {
  const name = "太郎";
  const title = "フロントエンドエンジニア";

  return (
    <div className="profile-card">
      <h2>{name}</h2>
      <p>{title}</p>
    </div>
  );
};

// Q5: 条件付きレンダリング（2パターン）
const Greeting = ({ isLoggedIn }: { isLoggedIn: boolean }) => {
  return (
    <div>
      {/* 三項演算子パターン */}
      {isLoggedIn ? <p>ようこそ</p> : <p>ログインしてください</p>}

      {/* && パターン */}
      {isLoggedIn && <p>ようこそ</p>}
      {!isLoggedIn && <p>ログインしてください</p>}
    </div>
  );
};

// Q6: 配列を <ul><li> でリスト表示（key付き）
const TechList = () => {
  const techs = ["React", "TypeScript", "Next.js"];

  return (
    <ul>
      {techs.map((tech) => (
        <li key={tech}>{tech}</li>
      ))}
    </ul>
  );
};

export { ProfileCard, Greeting, TechList };
