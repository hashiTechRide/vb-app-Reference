import React, { useState } from "react";

// Q4: 三目並べ（勝敗判定なし）
type SquareValue = "X" | "O" | null;

const TicTacToe = () => {
  const [board, setBoard] = useState<SquareValue[]>(Array(9).fill(null));
  const [isXNext, setIsXNext] = useState(true);

  const handleClick = (index: number) => {
    if (board[index] !== null) return; // 既にマークされている
    const newBoard = [...board];
    newBoard[index] = isXNext ? "X" : "O";
    setBoard(newBoard);
    setIsXNext(!isXNext);
  };

  return (
    <div>
      <p>次の手番: {isXNext ? "X" : "O"}</p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 60px)", gap: "4px" }}>
        {board.map((value, index) => (
          <button
            key={index}
            onClick={() => handleClick(index)}
            style={{
              width: 60,
              height: 60,
              fontSize: 24,
              fontWeight: "bold",
              cursor: "pointer",
            }}
          >
            {value}
          </button>
        ))}
      </div>
    </div>
  );
};

// Q5: Undo機能付き三目並べ
const TicTacToeWithUndo = () => {
  const [history, setHistory] = useState<SquareValue[][]>([Array(9).fill(null)]);
  const [currentMove, setCurrentMove] = useState(0);

  const board = history[currentMove];
  const isXNext = currentMove % 2 === 0;

  const handleClick = (index: number) => {
    if (board[index] !== null) return;
    const newBoard = [...board];
    newBoard[index] = isXNext ? "X" : "O";
    // 現在の手番以降の履歴を切り捨てて新しい手を追加
    const newHistory = history.slice(0, currentMove + 1);
    setHistory([...newHistory, newBoard]);
    setCurrentMove(newHistory.length);
  };

  const handleUndo = () => {
    if (currentMove > 0) {
      setCurrentMove(currentMove - 1);
    }
  };

  return (
    <div>
      <p>次の手番: {isXNext ? "X" : "O"}</p>
      <button onClick={handleUndo} disabled={currentMove === 0}>
        Undo（1手戻す）
      </button>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 60px)", gap: "4px" }}>
        {board.map((value, index) => (
          <button
            key={index}
            onClick={() => handleClick(index)}
            style={{ width: 60, height: 60, fontSize: 24, fontWeight: "bold" }}
          >
            {value}
          </button>
        ))}
      </div>
    </div>
  );
};

export { TicTacToe, TicTacToeWithUndo };
