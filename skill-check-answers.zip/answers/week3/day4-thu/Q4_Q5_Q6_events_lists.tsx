import React, { useState } from "react";

// Q4: テキスト入力→追加→リスト表示（追加後クリア）
const ItemList = () => {
  const [items, setItems] = useState<string[]>([]);
  const [input, setInput] = useState("");

  const handleAdd = () => {
    if (input.trim() === "") return;
    setItems([...items, input]);
    setInput(""); // 入力欄をクリア
  };

  return (
    <div>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && handleAdd()}
        placeholder="アイテムを入力"
      />
      <button onClick={handleAdd}>追加</button>
      <ul>
        {items.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  );
};

// Q5: 各アイテムに削除ボタン
const DeletableList = () => {
  const [items, setItems] = useState<string[]>(["React", "TypeScript", "Next.js"]);

  const handleDelete = (indexToDelete: number) => {
    setItems(items.filter((_, index) => index !== indexToDelete));
  };

  return (
    <ul>
      {items.map((item, index) => (
        <li key={index}>
          {item}
          <button onClick={() => handleDelete(index)}>削除</button>
        </li>
      ))}
    </ul>
  );
};

// Q6: クリックで選択状態をトグル（複数選択可）
const SelectableList = () => {
  const [items] = useState(["React", "TypeScript", "Next.js", "Tailwind"]);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

  const toggleSelection = (index: number) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(index)) {
        next.delete(index);
      } else {
        next.add(index);
      }
      return next;
    });
  };

  return (
    <ul>
      {items.map((item, index) => (
        <li
          key={index}
          onClick={() => toggleSelection(index)}
          style={{
            backgroundColor: selectedIds.has(index) ? "#bfdbfe" : "transparent",
            cursor: "pointer",
            padding: "8px",
          }}
        >
          {item} {selectedIds.has(index) && "✓"}
        </li>
      ))}
    </ul>
  );
};

export { ItemList, DeletableList, SelectableList };
