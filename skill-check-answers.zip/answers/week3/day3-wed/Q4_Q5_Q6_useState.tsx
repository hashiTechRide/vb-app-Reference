import React, { useState } from "react";

// Q4: カウンターコンポーネント
const Counter = () => {
  const [count, setCount] = useState(0);

  return (
    <div>
      <p>カウント: {count}</p>
      <button onClick={() => setCount(count + 1)}>+1</button>
      <button onClick={() => setCount(count - 1)}>-1</button>
      <button onClick={() => setCount(0)}>リセット</button>
    </div>
  );
};

// Q5: 文字列配列をstateで管理し、入力フォームから追加
const StringList = () => {
  const [items, setItems] = useState<string[]>([]);
  const [input, setInput] = useState("");

  const handleAdd = () => {
    if (input.trim() === "") return;
    setItems([...items, input]); // イミュータブルに更新
    setInput("");
  };

  return (
    <div>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="アイテムを入力"
      />
      <button onClick={handleAdd}>追加</button>
      <ul>
        {items.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  );
};

// Q6: オブジェクトのstateで name だけを更新
const UserForm = () => {
  const [user, setUser] = useState({ name: "太郎", age: 25 });

  const updateName = (newName: string) => {
    setUser({ ...user, name: newName }); // スプレッド構文で name だけ上書き
  };

  return (
    <div>
      <p>
        {user.name} ({user.age}歳)
      </p>
      <input
        value={user.name}
        onChange={(e) => updateName(e.target.value)}
      />
    </div>
  );
};

export { Counter, StringList, UserForm };
