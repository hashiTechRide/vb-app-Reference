import React, { useState } from "react";

// Q1, Q2, Q3: じゃんけんアプリ

type Hand = "rock" | "scissors" | "paper";
type Result = "win" | "lose" | "draw";

interface GameRecord {
  playerHand: Hand;
  cpuHand: Hand;
  result: Result;
}

const handLabels: Record<Hand, string> = {
  rock: "グー",
  scissors: "チョキ",
  paper: "パー",
};

// Q2: 型安全な勝敗判定関数
const judge = (player: Hand, cpu: Hand): Result => {
  if (player === cpu) return "draw";
  if (
    (player === "rock" && cpu === "scissors") ||
    (player === "scissors" && cpu === "paper") ||
    (player === "paper" && cpu === "rock")
  ) {
    return "win";
  }
  return "lose";
};

const getRandomHand = (): Hand => {
  const hands: Hand[] = ["rock", "scissors", "paper"];
  return hands[Math.floor(Math.random() * 3)];
};

const RockPaperScissors = () => {
  const [score, setScore] = useState({ win: 0, lose: 0, draw: 0 });
  const [history, setHistory] = useState<GameRecord[]>([]);
  const [lastResult, setLastResult] = useState<GameRecord | null>(null);

  const play = (playerHand: Hand) => {
    const cpuHand = getRandomHand();
    const result = judge(playerHand, cpuHand);

    const record: GameRecord = { playerHand, cpuHand, result };
    setLastResult(record);
    setScore((prev) => ({ ...prev, [result]: prev[result] + 1 }));
    // Q3: 直近5回の履歴を保持
    setHistory((prev) => [record, ...prev].slice(0, 5));
  };

  const resultLabels: Record<Result, string> = {
    win: "勝ち！",
    lose: "負け...",
    draw: "あいこ",
  };

  return (
    <div>
      <h2>じゃんけん</h2>
      <div>
        {(["rock", "scissors", "paper"] as Hand[]).map((hand) => (
          <button key={hand} onClick={() => play(hand)}>
            {handLabels[hand]}
          </button>
        ))}
      </div>

      {lastResult && (
        <div>
          <p>
            あなた: {handLabels[lastResult.playerHand]} vs CPU:{" "}
            {handLabels[lastResult.cpuHand]} → {resultLabels[lastResult.result]}
          </p>
        </div>
      )}

      <h3>スコア</h3>
      <p>
        {score.win}勝 {score.lose}敗 {score.draw}分
      </p>

      <h3>直近5回の履歴</h3>
      <ul>
        {history.map((record, index) => (
          <li key={index}>
            {handLabels[record.playerHand]} vs {handLabels[record.cpuHand]} →{" "}
            {resultLabels[record.result]}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RockPaperScissors;
