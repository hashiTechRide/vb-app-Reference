import React, { useState } from "react";

// Q1: ランダムな16進カラーコードを生成する関数
const generateRandomColor = (): string => {
  return `#${Math.floor(Math.random() * 0xffffff)
    .toString(16)
    .padStart(6, "0")}`;
};

// Q2 & Q3: カラーパレットジェネレーター
const ColorPaletteGenerator = () => {
  const [colors, setColors] = useState<string[]>(
    Array.from({ length: 5 }, () => generateRandomColor())
  );
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const regenerate = () => {
    setColors(Array.from({ length: 5 }, () => generateRandomColor()));
    setCopiedIndex(null);
  };

  // Q3: クリップボードにコピー
  const copyToClipboard = async (color: string, index: number) => {
    try {
      await navigator.clipboard.writeText(color);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    } catch (err) {
      console.error("コピーに失敗:", err);
    }
  };

  return (
    <div>
      <h2>カラーパレットジェネレーター</h2>
      <button onClick={regenerate}>Generate</button>
      <div style={{ display: "flex", gap: "8px", marginTop: "16px" }}>
        {colors.map((color, index) => (
          <div
            key={index}
            onClick={() => copyToClipboard(color, index)}
            style={{
              width: "100px",
              height: "100px",
              backgroundColor: color,
              display: "flex",
              alignItems: "flex-end",
              justifyContent: "center",
              cursor: "pointer",
              borderRadius: "8px",
              padding: "8px",
            }}
          >
            <span style={{ fontSize: "12px", color: "#fff", textShadow: "0 0 4px #000" }}>
              {copiedIndex === index ? "Copied!" : color}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ColorPaletteGenerator;
