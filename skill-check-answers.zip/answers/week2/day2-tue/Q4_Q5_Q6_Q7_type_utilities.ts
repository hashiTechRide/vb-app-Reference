// Q4, Q5, Q6, Q7: 型ユーティリティ

interface User {
  id: number;
  name: string;
  email: string;
  password: string;
}

// Q4: Omit で password を除いた PublicUser
type PublicUser = Omit<User, "password">;
// 結果: { id: number; name: string; email: string }

// Q5: Pick で name と email だけの UserSummary
type UserSummary = Pick<User, "name" | "email">;
// 結果: { name: string; email: string }

// Q6: Record<string, number> の説明と例
// Record<string, number> は、キーがstring、値がnumberであるオブジェクト型
const scores: Record<string, number> = {
  math: 90,
  english: 85,
  science: 92,
};

// Q7: Partial<User> を引数に取る updateUser 関数
function updateUser(currentUser: User, updates: Partial<User>): User {
  return { ...currentUser, ...updates };
}

// 使用例
const user: User = {
  id: 1,
  name: "太郎",
  email: "taro@example.com",
  password: "secret123",
};

const updated = updateUser(user, { name: "次郎", email: "jiro@example.com" });
console.log(updated);
// { id: 1, name: "次郎", email: "jiro@example.com", password: "secret123" }
