// Q1: TODOアプリのデータ型定義
interface Todo {
  id: number;
  title: string;
  completed: boolean;
  createdAt: Date;
}

type Filter = "all" | "active" | "completed";

// Q2: 完了済みのTodoだけを抽出する関数
const getCompletedTodos = (todos: Todo[]): Todo[] => {
  return todos.filter((todo) => todo.completed);
};

// Q3: 新しいTodoを追加する関数（イミュータブル）
const addTodo = (todos: Todo[], title: string): Todo[] => {
  const newTodo: Todo = {
    id: todos.length > 0 ? Math.max(...todos.map((t) => t.id)) + 1 : 1,
    title,
    completed: false,
    createdAt: new Date(),
  };
  return [...todos, newTodo];
};

// Q4: TODOアプリのロジック全体
const deleteTodo = (todos: Todo[], id: number): Todo[] => {
  return todos.filter((todo) => todo.id !== id);
};

const toggleTodo = (todos: Todo[], id: number): Todo[] => {
  return todos.map((todo) =>
    todo.id === id ? { ...todo, completed: !todo.completed } : todo
  );
};

const filterTodos = (todos: Todo[], filter: Filter): Todo[] => {
  switch (filter) {
    case "all":
      return todos;
    case "active":
      return todos.filter((todo) => !todo.completed);
    case "completed":
      return todos.filter((todo) => todo.completed);
  }
};

// 使用例
let todos: Todo[] = [];
todos = addTodo(todos, "TypeScript学習");
todos = addTodo(todos, "React学習");
todos = toggleTodo(todos, 1);
console.log(filterTodos(todos, "completed")); // TypeScript学習のみ
console.log(filterTodos(todos, "active"));    // React学習のみ
todos = deleteTodo(todos, 1);
console.log(todos); // React学習のみ
