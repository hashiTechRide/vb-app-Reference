// Q4: fetch で POST リクエスト（JSON ボディ付き）
async function createUser(name: string, email: string): Promise<void> {
  const response = await fetch("https://jsonplaceholder.typicode.com/users", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name, email }),
  });

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  const data = await response.json();
  console.log("Created:", data);
}

// Q5: ステータスコードチェック付き共通ラッパー関数
async function fetchWithCheck<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, options);

  if (!response.ok) {
    throw new Error(
      `API Error: ${response.status} ${response.statusText} - URL: ${url}`
    );
  }

  return response.json() as Promise<T>;
}

// 使用例
interface User {
  id: number;
  name: string;
  email: string;
}

async function main(): Promise<void> {
  try {
    // GET
    const user = await fetchWithCheck<User>(
      "https://jsonplaceholder.typicode.com/users/1"
    );
    console.log(user.name);

    // POST
    const newUser = await fetchWithCheck<User>(
      "https://jsonplaceholder.typicode.com/users",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "太郎", email: "taro@example.com" }),
      }
    );
    console.log(newUser);
  } catch (error) {
    console.error(error);
  }
}

main();
