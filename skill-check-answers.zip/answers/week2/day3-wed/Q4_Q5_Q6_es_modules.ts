// Q4: スプレッド構文でオブジェクトのコピーと上書き
const user = { name: "太郎", age: 25, email: "taro@example.com" };
const updatedUser = { ...user, name: "次郎" };
console.log(updatedUser); // { name: "次郎", age: 25, email: "taro@example.com" }

// Q5: Optional Chaining と Nullish Coalescing
// user?.address?.city ?? "不明" の意味:
// userが存在し、そのaddressが存在し、そのcityが存在すればcityの値を返す。
// いずれかがnull/undefinedなら "不明" を返す。

// if文での同等処理
interface UserWithAddress {
  address?: {
    city?: string;
  };
}

function getCityName(user?: UserWithAddress): string {
  if (user !== undefined && user !== null) {
    if (user.address !== undefined && user.address !== null) {
      if (user.address.city !== undefined && user.address.city !== null) {
        return user.address.city;
      }
    }
  }
  return "不明";
}

// Optional Chaining版（簡潔）
const getCityShort = (user?: UserWithAddress): string => {
  return user?.address?.city ?? "不明";
};

// Q6: テンプレートリテラル
const name = "太郎";
const age = 25;
const introduction = `こんにちは、私は${name}です。${age}歳です。`;
console.log(introduction); // こんにちは、私は太郎です。25歳です。
