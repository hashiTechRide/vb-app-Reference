// Week 2 総合チェック コード回答

// Q5: ジェネリック関数 identity
function identity<T>(arg: T): T {
  return arg;
}
const result = identity<string>("hello");
// 戻り値型は string

// Q6: Pick と Omit が同じ結果になる User 型
// Pick<User, "name" | "email"> = Omit<User, "id" | "password">
// → User は id, name, email, password の4つのプロパティを持つ
interface User {
  id: number;
  name: string;
  email: string;
  password: string;
}

type ByPick = Pick<User, "name" | "email">;
type ByOmit = Omit<User, "id" | "password">;
// 両方とも { name: string; email: string } になる
