// Q4: fetchでデータを取得する async 関数（型付き）
interface UserResponse {
  id: number;
  name: string;
  username: string;
  email: string;
}

async function fetchUser(): Promise<void> {
  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/users/1");
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const user: UserResponse = await response.json();
    console.log(`名前: ${user.name}`);
  } catch (error) {
    console.error("データ取得に失敗:", error);
  }
}

fetchUser();

// Q5: Promise.all で3つのAPIを並列に呼び出す
async function fetchMultipleUsers(): Promise<void> {
  try {
    const [user1, user2, user3] = await Promise.all([
      fetch("https://jsonplaceholder.typicode.com/users/1").then((r) => r.json()),
      fetch("https://jsonplaceholder.typicode.com/users/2").then((r) => r.json()),
      fetch("https://jsonplaceholder.typicode.com/users/3").then((r) => r.json()),
    ]);
    console.log(user1.name, user2.name, user3.name);
  } catch (error) {
    console.error("いずれかのリクエストが失敗:", error);
  }
}

// Q6: sleep 関数
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// 使用例
async function main(): Promise<void> {
  console.log("開始");
  await sleep(2000); // 2秒待つ
  console.log("2秒経過");
  await sleep(1000); // さらに1秒待つ
  console.log("3秒経過");
}

main();
