#!/bin/bash

# Q4: featureブランチの作成→変更→コミット→マージ

# 新しいfeatureブランチを作成して切替
git checkout -b feature/add-login

# ファイルを変更（例）
echo "console.log('login feature');" >> login.ts

# 変更をステージング
git add login.ts

# コミット
git commit -m "feat: ログイン機能を追加"

# mainブランチに戻る
git checkout main

# featureブランチをマージ
git merge feature/add-login

# 不要になったブランチを削除
git branch -d feature/add-login


# Q5: 意図的にコンフリクトを起こし、手動で解決する手順

# ---- 準備 ----
# mainブランチでファイルを作成
echo "Hello World" > greeting.txt
git add greeting.txt
git commit -m "initial greeting"

# ブランチAを作成して変更
git checkout -b branch-a
echo "Hello from Branch A" > greeting.txt
git add greeting.txt
git commit -m "change from branch A"

# mainに戻ってブランチBを作成して変更
git checkout main
git checkout -b branch-b
echo "Hello from Branch B" > greeting.txt
git add greeting.txt
git commit -m "change from branch B"

# ---- コンフリクト発生 ----
# mainにブランチAをマージ（成功）
git checkout main
git merge branch-a

# mainにブランチBをマージ（コンフリクト発生！）
git merge branch-b
# CONFLICT (content): Merge conflict in greeting.txt

# ---- 手動で解決 ----
# greeting.txt を開いて、コンフリクトマーカーを手動で編集
# <<<<<<< HEAD
# Hello from Branch A
# =======
# Hello from Branch B
# >>>>>>> branch-b

# 正しい内容に修正
echo "Hello from both branches" > greeting.txt

# 解決済みとしてステージング
git add greeting.txt

# マージコミット
git commit -m "merge: resolve conflict in greeting.txt"
