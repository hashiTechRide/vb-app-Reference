// Q4: ジェネリック関数 getFirst
function getFirst<T>(arr: T[]): T | undefined {
  return arr[0];
}

console.log(getFirst([1, 2, 3]));         // 1
console.log(getFirst(["a", "b", "c"]));   // "a"
console.log(getFirst([]));                // undefined

// Q5: ApiResponse ジェネリック型
interface User {
  id: number;
  name: string;
  email: string;
}

type ApiResponse<T> = {
  data: T;
  status: number;
  message: string;
};

const response: ApiResponse<User[]> = {
  data: [
    { id: 1, name: "太郎", email: "taro@example.com" },
    { id: 2, name: "花子", email: "hanako@example.com" },
  ],
  status: 200,
  message: "Success",
};

// Q6: KeyValueStore クラス
class KeyValueStore<K, V> {
  private store = new Map<K, V>();

  set(key: K, value: V): void {
    this.store.set(key, value);
  }

  get(key: K): V | undefined {
    return this.store.get(key);
  }

  has(key: K): boolean {
    return this.store.has(key);
  }
}

// 使用例
const store = new KeyValueStore<string, number>();
store.set("age", 25);
console.log(store.get("age")); // 25
console.log(store.has("age")); // true
console.log(store.has("name")); // false
