// Q4: 「Hello, TypeScript!」とコンソールに出力する関数
function greet(message: string): void {
  console.log(message);
}

greet("Hello, TypeScript!");
