// Week 1 総合チェック コード回答

// Q5: 偶数だけをフィルタして返すアロー関数
const filterEven = (numbers: number[]): number[] => {
  return numbers.filter((n) => n % 2 === 0);
};

console.log(filterEven([1, 2, 3, 4, 5, 6])); // [2, 4, 6]

// Q7: VB.NETの Function Add をTypeScriptで書き直し
// VB.NET: Function Add(a As Integer, b As Integer) As Integer
const addFunc = (a: number, b: number): number => {
  return a + b;
};
