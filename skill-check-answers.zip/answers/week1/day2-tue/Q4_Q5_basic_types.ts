// Q4: 適切な型注釈つきで変数を宣言
const name: string = "太郎";
const age: number = 30;
const isMarried: boolean = false;
const hobbies: string[] = ["読書", "ゲーム", "料理"];
const coordinate: [number, number] = [35.6762, 139.6503];

// Q5: enum Direction
enum Direction {
  Up,    // 0
  Down,  // 1
  Left,  // 2
  Right, // 3
}

// Up の値は 0。enumは 0 から自動的にインクリメントされる
console.log(Direction.Up); // 0
