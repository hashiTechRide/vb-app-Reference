// Q4: interface で定義
interface User {
  id: number;
  name: string;
  email: string;
}

interface AdminUser extends User {
  permissionLevel: number;
}

// Q5: type とインターセクション（&）で書き直し
type UserType = {
  id: number;
  name: string;
  email: string;
};

type AdminUserType = UserType & {
  permissionLevel: number;
};

// Q6: ネストされた型定義
interface Employee {
  name: string;
  department: string;
  skills: string[];
}

interface Company {
  name: string;
  employees: Employee[];
}

// 使用例
const company: Company = {
  name: "Tech Corp",
  employees: [
    { name: "太郎", department: "開発", skills: ["TypeScript", "React"] },
    { name: "花子", department: "デザイン", skills: ["Figma", "CSS"] },
  ],
};
