import * as fs from "fs";

// Q1: コマンドライン引数による処理分岐
const args = process.argv.slice(2);
const command = args[0];

switch (command) {
  case "add":
    console.log("追加処理を実行します");
    break;
  case "list":
    console.log("一覧表示を実行します");
    break;
  case "delete":
    console.log("削除処理を実行します");
    break;
  default:
    console.log("使い方: ts-node cli.ts [add|list|delete]");
    break;
}

// Q2: JSONファイルの型安全な読み書き
function readJson<T>(filePath: string): T {
  const raw = fs.readFileSync(filePath, "utf-8");
  return JSON.parse(raw) as T;
}

function writeJson<T>(filePath: string, data: T): void {
  const json = JSON.stringify(data, null, 2);
  fs.writeFileSync(filePath, json, "utf-8");
}

// 使用例
interface TodoItem {
  id: number;
  title: string;
  completed: boolean;
}

// 読み込み
const todos = readJson<TodoItem[]>("./todos.json");
console.log(todos);

// 書き込み
const newTodos: TodoItem[] = [
  { id: 1, title: "TypeScript学習", completed: false },
];
writeJson("./todos.json", newTodos);

// Q3: 型定義の理由
// TodoItem型を定義した理由：
// - id: 一意識別子として数値を使用（自動採番を想定）
// - title: TODOの内容を文字列で表現
// - completed: 完了状態を真偽値で管理（シンプルなトグル操作に最適）
// ジェネリック型 T を使うことで、JSON読み書き関数を任意の型で再利用可能にしている
