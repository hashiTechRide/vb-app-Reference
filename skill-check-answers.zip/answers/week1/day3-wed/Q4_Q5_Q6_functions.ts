// Q4: 2つの数値を受け取り、合計を返すアロー関数
const add = (a: number, b: number): number => a + b;

console.log(add(3, 5)); // 8

// Q5: 名前（必須）と年齢（オプション）を受け取り、挨拶文を返す関数
const greet = (name: string, age?: number): string => {
  const ageText = age !== undefined ? `${age}歳` : "年齢不明";
  return `こんにちは、${name}さん（${ageText}）`;
};

console.log(greet("太郎", 25)); // こんにちは、太郎さん（25歳）
console.log(greet("花子"));     // こんにちは、花子さん（年齢不明）

// Q6: mapArray - Array.prototype.map の再実装
function mapArray<T, U>(arr: T[], callback: (item: T, index: number) => U): U[] {
  const result: U[] = [];
  for (let i = 0; i < arr.length; i++) {
    result.push(callback(arr[i], i));
  }
  return result;
}

// 使用例
const numbers = [1, 2, 3, 4, 5];
const doubled = mapArray(numbers, (n) => n * 2);
console.log(doubled); // [2, 4, 6, 8, 10]

const strings = mapArray(numbers, (n) => `Item ${n}`);
console.log(strings); // ["Item 1", "Item 2", "Item 3", "Item 4", "Item 5"]
