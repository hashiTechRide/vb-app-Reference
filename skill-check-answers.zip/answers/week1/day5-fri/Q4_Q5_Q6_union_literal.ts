// Q4: APIレスポンス状態のリテラル型ユニオン
type ApiStatus = "loading" | "success" | "error";

// Q5: 型ガードを使った関数
const processValue = (value: string | number): string | number => {
  if (typeof value === "string") {
    return value.toUpperCase();
  } else {
    return value * 2;
  }
};

console.log(processValue("hello")); // "HELLO"
console.log(processValue(21));      // 42

// Q6: Discriminated Union と面積計算
type Circle = {
  kind: "circle";
  radius: number;
};

type Rectangle = {
  kind: "rectangle";
  width: number;
  height: number;
};

type Triangle = {
  kind: "triangle";
  base: number;
  height: number;
};

type Shape = Circle | Rectangle | Triangle;

function calculateArea(shape: Shape): number {
  switch (shape.kind) {
    case "circle":
      return Math.PI * shape.radius ** 2;
    case "rectangle":
      return shape.width * shape.height;
    case "triangle":
      return (shape.base * shape.height) / 2;
  }
}

// 使用例
console.log(calculateArea({ kind: "circle", radius: 5 }));             // 78.54...
console.log(calculateArea({ kind: "rectangle", width: 4, height: 6 })); // 24
console.log(calculateArea({ kind: "triangle", base: 3, height: 8 }));   // 12
