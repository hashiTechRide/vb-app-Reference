import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import React, { useState, useEffect } from "react";

// ---- テスト対象コンポーネント ----

// カウンターコンポーネント
const Counter = () => {
  const [count, setCount] = useState(0);
  return (
    <div>
      <p>カウント: {count}</p>
      <button onClick={() => setCount(count + 1)}>+1</button>
    </div>
  );
};

// 非同期データ取得コンポーネント
const AsyncUserList = () => {
  const [users, setUsers] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/users")
      .then((res) => res.json())
      .then((data) => {
        setUsers(data);
        setLoading(false);
      });
  }, []);

  if (loading) return <p>読み込み中...</p>;
  return (
    <ul>
      {users.map((user) => (
        <li key={user}>{user}</li>
      ))}
    </ul>
  );
};

// ---- テスト ----

// Q4: カウンターコンポーネントのテスト
describe("Counter", () => {
  test("ボタンクリックで数値が増える", () => {
    render(<Counter />);

    // 初期値の確認
    expect(screen.getByText("カウント: 0")).toBeInTheDocument();

    // ボタンクリック
    fireEvent.click(screen.getByRole("button", { name: "+1" }));

    // 値が1に更新されたか確認
    expect(screen.getByText("カウント: 1")).toBeInTheDocument();
  });
});

// Q5: 非同期コンポーネントのテスト（waitFor使用）
describe("AsyncUserList", () => {
  beforeEach(() => {
    global.fetch = jest.fn(() =>
      Promise.resolve({
        json: () => Promise.resolve(["太郎", "花子", "次郎"]),
      })
    ) as jest.Mock;
  });

  test("データ取得後にユーザー一覧が表示される", async () => {
    render(<AsyncUserList />);

    // ローディング表示を確認
    expect(screen.getByText("読み込み中...")).toBeInTheDocument();

    // データが表示されるまで待機
    await waitFor(() => {
      expect(screen.getByText("太郎")).toBeInTheDocument();
      expect(screen.getByText("花子")).toBeInTheDocument();
      expect(screen.getByText("次郎")).toBeInTheDocument();
    });
  });
});
