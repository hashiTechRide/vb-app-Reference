// Day 4 Q4: カスタムカラー追加
// tailwind.config.js

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class", // Day 4 Q1: class戦略でダークモード有効化
  theme: {
    extend: {
      colors: {
        brand: "#3B82F6", // カスタムカラー → bg-brand, text-brand で使える
      },
    },
  },
  plugins: [],
};

// 使用例: <div class="bg-brand text-white p-4">ブランドカラー</div>
