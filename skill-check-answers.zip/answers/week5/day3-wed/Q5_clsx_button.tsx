import React from "react";
import clsx from "clsx";

// Day 3 Q5: clsx を使ったスタイル切替ボタン
interface ToggleButtonProps {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}

const ToggleButton = ({ active, onClick, children }: ToggleButtonProps) => {
  return (
    <button
      onClick={onClick}
      className={clsx(
        "px-4 py-2 rounded-lg transition-colors duration-200",
        {
          "bg-blue-500 text-white": active,
          "bg-gray-200 text-gray-700 hover:bg-gray-300": !active,
        }
      )}
    >
      {children}
    </button>
  );
};

export default ToggleButton;
