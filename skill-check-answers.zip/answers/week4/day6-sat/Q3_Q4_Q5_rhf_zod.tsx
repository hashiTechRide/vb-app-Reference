import React from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

// Q3: zodスキーマ定義
const userSchema = z.object({
  name: z.string().min(2, "名前は2文字以上で入力してください"),
  email: z.string().email("有効なメールアドレスを入力してください"),
  age: z.number().min(18, "18歳以上である必要があります").optional(),
});

type UserFormData = z.infer<typeof userSchema>;

// Q4: React Hook Form + zod フォームコンポーネント
const UserFormComponent = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<UserFormData>({
    resolver: zodResolver(userSchema),
  });

  const onSubmit = (data: UserFormData) => {
    console.log("送信データ:", data);
  };

  return (
    <div>
      <h2>ユーザー登録</h2>
      <div>
        <div>
          <label>名前:</label>
          <input {...register("name")} />
          {errors.name && <p style={{ color: "red" }}>{errors.name.message}</p>}
        </div>
        <div>
          <label>メール:</label>
          <input {...register("email")} />
          {errors.email && <p style={{ color: "red" }}>{errors.email.message}</p>}
        </div>
        <div>
          <label>年齢:</label>
          <input type="number" {...register("age", { valueAsNumber: true })} />
          {errors.age && <p style={{ color: "red" }}>{errors.age.message}</p>}
        </div>
        <button onClick={handleSubmit(onSubmit)}>送信</button>
      </div>
    </div>
  );
};

// Q5: パスワード一致検証付きフォーム
const passwordSchema = z
  .object({
    password: z.string().min(8, "パスワードは8文字以上"),
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "パスワードが一致しません",
    path: ["confirmPassword"],
  });

type PasswordFormData = z.infer<typeof passwordSchema>;

const PasswordForm = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<PasswordFormData>({
    resolver: zodResolver(passwordSchema),
  });

  const onSubmit = (data: PasswordFormData) => {
    console.log("パスワード設定完了:", data);
  };

  return (
    <div>
      <h2>パスワード設定</h2>
      <div>
        <div>
          <label>パスワード:</label>
          <input type="password" {...register("password")} />
          {errors.password && <p style={{ color: "red" }}>{errors.password.message}</p>}
        </div>
        <div>
          <label>確認用パスワード:</label>
          <input type="password" {...register("confirmPassword")} />
          {errors.confirmPassword && (
            <p style={{ color: "red" }}>{errors.confirmPassword.message}</p>
          )}
        </div>
        <button onClick={handleSubmit(onSubmit)}>設定</button>
      </div>
    </div>
  );
};

export { UserFormComponent, PasswordForm };
