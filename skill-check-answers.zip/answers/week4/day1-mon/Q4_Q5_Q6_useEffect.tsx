import React, { useState, useEffect } from "react";

// Q4: マウント時にAPIを呼び出し、ローディング・エラー状態も管理
interface User {
  id: number;
  name: string;
  email: string;
}

const UserList = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch("https://jsonplaceholder.typicode.com/users");
        if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
        const data: User[] = await response.json();
        setUsers(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Unknown error");
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []); // 空配列 → マウント時に1回だけ実行

  if (loading) return <p>読み込み中...</p>;
  if (error) return <p>エラー: {error}</p>;

  return (
    <ul>
      {users.map((user) => (
        <li key={user.id}>{user.name} ({user.email})</li>
      ))}
    </ul>
  );
};

// Q5: setInterval でカウントアップ（クリーンアップ付き）
const Timer = () => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCount((prev) => prev + 1);
    }, 1000);

    // クリーンアップ関数
    return () => clearInterval(intervalId);
  }, []);

  return <p>経過時間: {count}秒</p>;
};

// Q6: ウィンドウリサイズ監視
const WindowSize = () => {
  const [size, setSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    const handleResize = () => {
      setSize({ width: window.innerWidth, height: window.innerHeight });
    };

    window.addEventListener("resize", handleResize);

    // クリーンアップ: イベントリスナーを解除
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <p>
      ウィンドウサイズ: {size.width} x {size.height}
    </p>
  );
};

export { UserList, Timer, WindowSize };
