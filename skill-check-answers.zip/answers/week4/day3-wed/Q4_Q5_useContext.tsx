import React, { createContext, useContext, useState, ReactNode } from "react";

// Q4: テーマContext + Provider + useTheme カスタムフック + 切替ボタン
type Theme = "light" | "dark";

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

// カスタムフック
const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
};

// Provider
const ThemeProvider = ({ children }: { children: ReactNode }) => {
  const [theme, setTheme] = useState<Theme>("light");
  const toggleTheme = () => setTheme((prev) => (prev === "light" ? "dark" : "light"));

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

// 切替ボタン
const ThemeToggleButton = () => {
  const { theme, toggleTheme } = useTheme();
  return (
    <button onClick={toggleTheme}>
      現在のテーマ: {theme} （クリックで切替）
    </button>
  );
};

// Q5: 3階層コンポーネント比較

// --- Contextなし（props drilling） ---
const ChildWithoutContext = ({ message }: { message: string }) => {
  return <p>{message}</p>;
};

const ParentWithoutContext = ({ message }: { message: string }) => {
  return <ChildWithoutContext message={message} />;
};

const AppWithoutContext = () => {
  return <ParentWithoutContext message="Hello from App" />;
};

// --- Contextあり ---
const MessageContext = createContext<string>("");

const ChildWithContext = () => {
  const message = useContext(MessageContext);
  return <p>{message}</p>;
};

const ParentWithContext = () => {
  return <ChildWithContext />;
};

const AppWithContext = () => {
  return (
    <MessageContext.Provider value="Hello from App">
      <ParentWithContext />
    </MessageContext.Provider>
  );
};
// → Contextありでは Parent がmessageを中継する必要がない

export {
  ThemeProvider,
  ThemeToggleButton,
  useTheme,
  AppWithoutContext,
  AppWithContext,
};
