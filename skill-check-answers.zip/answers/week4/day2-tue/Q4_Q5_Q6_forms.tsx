import React, { useState } from "react";

// Q4 & Q5: フォーム（バリデーション付き）
interface FormData {
  name: string;
  email: string;
  password: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  password?: string;
}

const RegistrationForm = () => {
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    password: "",
  });
  const [errors, setErrors] = useState<FormErrors>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Q5: バリデーション
  const validate = (): FormErrors => {
    const newErrors: FormErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "名前は必須です";
    }
    if (!formData.email.includes("@")) {
      newErrors.email = "メールアドレスに@を含めてください";
    }
    if (formData.password.length < 8) {
      newErrors.password = "パスワードは8文字以上にしてください";
    }
    return newErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault(); // ページ遷移を防ぐ
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      console.log("送信データ:", formData);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>名前:</label>
        <input name="name" value={formData.name} onChange={handleChange} />
        {errors.name && <p style={{ color: "red" }}>{errors.name}</p>}
      </div>
      <div>
        <label>メール:</label>
        <input name="email" value={formData.email} onChange={handleChange} />
        {errors.email && <p style={{ color: "red" }}>{errors.email}</p>}
      </div>
      <div>
        <label>パスワード:</label>
        <input name="password" type="password" value={formData.password} onChange={handleChange} />
        {errors.password && <p style={{ color: "red" }}>{errors.password}</p>}
      </div>
      <button type="submit">送信</button>
    </form>
  );
};

// Q6: 動的フィールド追加・削除フォーム
const DynamicSkillForm = () => {
  const [skills, setSkills] = useState<string[]>([""]);

  const addField = () => setSkills([...skills, ""]);

  const removeField = (index: number) => {
    setSkills(skills.filter((_, i) => i !== index));
  };

  const updateField = (index: number, value: string) => {
    setSkills(skills.map((skill, i) => (i === index ? value : skill)));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("スキル:", skills.filter((s) => s.trim() !== ""));
  };

  return (
    <form onSubmit={handleSubmit}>
      <h3>スキル入力</h3>
      {skills.map((skill, index) => (
        <div key={index} style={{ marginBottom: "8px" }}>
          <input
            value={skill}
            onChange={(e) => updateField(index, e.target.value)}
            placeholder={`スキル ${index + 1}`}
          />
          {skills.length > 1 && (
            <button type="button" onClick={() => removeField(index)}>削除</button>
          )}
        </div>
      ))}
      <button type="button" onClick={addField}>+ スキル追加</button>
      <button type="submit">送信</button>
    </form>
  );
};

export { RegistrationForm, DynamicSkillForm };
