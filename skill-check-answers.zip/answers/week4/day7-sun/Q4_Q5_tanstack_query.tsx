import React from "react";
import { useQuery } from "@tanstack/react-query";

// Q4: TanStack Query でユーザー一覧取得
interface User {
  id: number;
  name: string;
  email: string;
}

const fetchUsers = async (): Promise<User[]> => {
  const response = await fetch("https://jsonplaceholder.typicode.com/users");
  if (!response.ok) throw new Error("Failed to fetch users");
  return response.json();
};

const UserListWithQuery = () => {
  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["users"],
    queryFn: fetchUsers,
    staleTime: 5 * 60 * 1000, // 5分間はstaleにならない
  });

  if (isLoading) return <p>読み込み中...</p>;
  if (isError) return <p>エラー: {error.message}</p>;

  return (
    <ul>
      {data?.map((user) => (
        <li key={user.id}>
          {user.name} ({user.email})
        </li>
      ))}
    </ul>
  );
};

// Q5: Zustand + TanStack Query 組み合わせ
// → Q3_zustand_store.ts のstoreと組み合わせる想定

import { create } from "zustand";

interface FavoriteStore {
  favoriteIds: Set<number>;
  toggleFavorite: (id: number) => void;
  isFavorite: (id: number) => boolean;
}

const useFavoriteStore = create<FavoriteStore>((set, get) => ({
  favoriteIds: new Set(),
  toggleFavorite: (id: number) =>
    set((state) => {
      const next = new Set(state.favoriteIds);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return { favoriteIds: next };
    }),
  isFavorite: (id: number) => get().favoriteIds.has(id),
}));

const UserListWithFavorites = () => {
  const { data, isLoading } = useQuery({
    queryKey: ["users"],
    queryFn: fetchUsers,
  });
  const { toggleFavorite, isFavorite } = useFavoriteStore();

  if (isLoading) return <p>読み込み中...</p>;

  return (
    <ul>
      {data?.map((user) => (
        <li key={user.id}>
          {user.name}
          <button onClick={() => toggleFavorite(user.id)}>
            {isFavorite(user.id) ? "★ お気に入り解除" : "☆ お気に入り"}
          </button>
        </li>
      ))}
    </ul>
  );
};

export { UserListWithQuery, UserListWithFavorites, useFavoriteStore };
