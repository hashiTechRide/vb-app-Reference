// Q3: Zustand カウンターstore
import { create } from "zustand";

interface CounterStore {
  count: number;
  increment: () => void;
  decrement: () => void;
  reset: () => void;
}

const useCounterStore = create<CounterStore>((set) => ({
  count: 0,
  increment: () => set((state) => ({ count: state.count + 1 })),
  decrement: () => set((state) => ({ count: state.count - 1 })),
  reset: () => set({ count: 0 }),
}));

// コンポーネントから使用
// const CounterComponent = () => {
//   const { count, increment, decrement, reset } = useCounterStore();
//   return (
//     <div>
//       <p>{count}</p>
//       <button onClick={increment}>+1</button>
//       <button onClick={decrement}>-1</button>
//       <button onClick={reset}>Reset</button>
//     </div>
//   );
// };

export { useCounterStore };
